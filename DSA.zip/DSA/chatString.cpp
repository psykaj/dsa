#include <iostream>
#include <string.h>
using namespace std;

int main()
{
    //reverse char array;
    char arr[] = "Pankaj";
    /*int n = strlen(arr);
    int s = 0;
    int e = n-1;
    while(s<=e)
    {
        swap(arr[s],arr[e]);
        s++;
        e--;
    }
    
    cout<<arr<<endl;*/
    
    //length of char array
    int len = 0;
    int i = 0;
    while(arr[i] != '\0')
    {
        len++;
        i++;
    }
    cout<<"Length -> "<<len<<endl;

    return 0;
}
