//Convert binary to Octal
#include <iostream>
using namespace std;
//tc = O(N);
//sc = O(1);
int main()
{
	string str = "1100110";
	
	int n = str.length();
	
	cout<<n<<endl; //Length before making divi by 3
	
	if(n % 3 == 1) //ager last mai 1 hai tho "00" add karo to make it divisible by 3
	{
	    str = "00" + str;
	}
	else if(n % 3 == 2)
	{
	    str = "0" + str; //ager last mai 1 hai tho "0" add karo to make it divisible by 3
	}
	n = str.length();
	
	cout<<n<<endl; //length after making n divisible by 3 
	
	string ans = "";
	
	for(int i=0;i<n;i += 3) //always increment by 3 
	{
	    int temp = (str[i] - '0') * 4 + (str[i+1] - '0') * 2 + (str[i+2] - '0') * 1;
	    cout<<"Temp : "<<temp<<endl;
	    ans += (temp + '0');
	    cout<<"Ans : "<<ans<<endl;
	}
	cout<<ans<<endl;
	
    return 0;
}
