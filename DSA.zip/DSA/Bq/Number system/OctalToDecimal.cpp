#include <iostream>
#include <math.h>
using namespace std;
//Tc = O(N); where n is the number of digits in the Octal Number.
//Sc = O(1);
int OctaltoDecimal(int Octal)
{
    int decimal = 0;
    int i = 0;
    while(Octal != 0)
    {
        int lastDigit = Octal % 10;
        decimal += (lastDigit * pow(8,i));
        i++;
        Octal = Octal / 10;
    }
    return decimal;
}

int main()
{
    int Octal = 345;
    cout <<"The decimal equivalent of the given octal number is "<<OctaltoDecimal(Octal) << endl;
    return 0;
}
