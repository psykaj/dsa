/*#include <iostream>
#include <math.h>
using namespace std;
//Tc = O(n log n)
//Sc = O(1)
int DecimaltoOctal(int decimal)
{
    int Octal = 0;
    int i = 0;
    while(decimal != 0)
    {
        int lastDigit = decimal % 8;
        cout<<"lastDigit : "<<lastDigit<<endl;
        Octal += lastDigit * pow(10,i);
        cout<<"Octal : "<<Octal<<endl;
        i++;
        cout<<"i : "<<i<<endl;
        decimal = decimal / 8;
        cout<<"Decimal : "<<decimal<<endl;
    }
    return Octal;
}

int main()
{
    int decimal = 136;
    cout <<"The Octal conversion of the given decimal number is "<<DecimaltoOctal(decimal) << endl;
    return 0;
}*/
