//Convert binary to decimal
#include <iostream>
using namespace std;
//tc = O(N);
//sc = O(1);
int main()
{
	string str = "1011";
	int n = str.length(); 
	int sum = 0;
	int base = 1;
	for(int i = n-1;i>=0;i--)
	{
	    if(str[i] == '1')
	    {
	        sum += base;
	    }
	    base = base * 2;
	}
	cout<<sum;
	
	//cout<<stoi(str,0,2);  tc = O(n), sc = o(1);
    return 0;
}
