//Convert binary to Octal
#include <iostream>
using namespace std;
//tc = O(Nlogn);
//sc = O(32);
int main()
{

	int n = 28;
	int binary[32] = {0}; //All element is 0 in array 
	cout<<"All the element initally at binary array : ";
	for(int i=0;i<32;i++)
	{
	    cout<<binary[i]<<" ";
	}
	cout<<endl;
	int i=0;
	while(n)
	{
	    int digit = n % 2;
	    binary[i] = digit;
	    cout<<"Binary : "<<binary[i]<<endl;
	    i++;
	    cout<<"i : "<<i<<endl;
	    n = n / 2;
	    cout<<"n : "<<n<<endl;
	}
	
	cout<<"The final decimal to binary is : ";
	for(int index=i-1;index>=0;index--)
	{
	    cout<<binary[index]<<" ";
	}
	cout<<endl;
	
    return 0;
}
