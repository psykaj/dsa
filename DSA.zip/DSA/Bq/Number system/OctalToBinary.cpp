#include <iostream>
#include <math.h>
using namespace std;
//Tc = O(N log n);
//Sc = O(1);
int OctaltoDecimal(int Octal)
{
    int Decimal = 0;
    int i = 0;
    while(Octal != 0)
    {
        int lastDigit = Octal % 10;
        Decimal += (lastDigit * pow(8,i));
        i++;
        Octal = Octal / 10;
    }
    return Decimal;
}

int DecimaltoBinary(int Decimal)
{
    int binary = 0;
    int i = 0;
    while(Decimal != 0)
    {
        int lastDigit = Decimal % 2;
        binary += (lastDigit * pow(10,i));
        i++;
        Decimal = Decimal / 2;
    }
    return binary;
}


int main()
{
    int Octal = 345;
    int Decimal = OctaltoDecimal(Octal);
    cout << "The binary conversion of the given octal number is "<<DecimaltoBinary(Decimal) << endl;
    return 0;
}
