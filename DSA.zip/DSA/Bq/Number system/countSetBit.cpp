#include <iostream>
using namespace std;
int countSetBit(int n)
{
    int count = 0;
    while(n > 0)
    {
        // int lastDigit = n % 2;
        
        // lsb(least significant beat) last 
        int lastDigit = n & 1;
        if(lastDigit == 1)
        {
            count++;
        }
        // n = n / 2;
        
        // same as divide by 2
        n = n >> 1;
    }
    // cout<<count<<endl;
    return count;
}

int main()
{
    int n;
    cin>>n;
    
    int ans = countSetBit(n);
    cout<<"The set bit of "<<n<<" is : "<<ans<<endl;
    return 0;
}
