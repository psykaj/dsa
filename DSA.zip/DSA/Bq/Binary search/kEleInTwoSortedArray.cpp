
//brute force approch
#include <iostream>
using namespace std;
//Tc = O(K) -> cause we iterate k times 
//Sc = O(1) -> cause we do not use any data structure 
/*int kthElement(int arr1[],int n,int arr2[],int m,int k)
{
    int p1 = 0;
    int p2 = 0;
    int count = 0;
    int ans = 0;
    
    while(p1 < n && p2 < m)
    {
        if(count == k)
        {
            break;
        }
        
        if(arr1[p1] < arr2[p2])
        {
            ans = arr1[p1];
            p1++;
        }
        else
        {
            ans = arr2[p2];
            p2++;
        }
        count++;
    }
    
    if(count != k)
    {
        if(p1 != n-1)
        {
            ans = arr1[count - k];
        }
        else
        {
            ans = arr2[count - k];
        }
    }
    
    return ans;
}

int main()
{
    int arr1[] = {2,3,6,7,9};
    int arr2[] = {1,4,8,10};
    int n = sizeof(arr1)/sizeof(arr1[0]);
    int m = sizeof(arr2)/sizeof(arr2[0]);
    int k = 5;
    cout<<"The kth element in final sorted array is : "<<kthElement(arr1,n,arr2,m,k);
    return 0;
}*/


//optimal approch (binary search)
#include <iostream>
#include <climits>
using namespace std;
//Tc = log(min(n,m));
//Sc = O(1);
int kthElement(int arr1[],int n,int arr2[],int m,int k)
{
    int start = max(0,k-n);
    int end = min(k,m);
    
    while(start <= end)
    {
        int cut1 = (start + end) >> 1;
        int cut2 = k - cut1;
        
        int l1 = cut1 == 0 ? INT_MIN : arr1[cut1 - 1];
        int l2 = cut2 == 0 ? INT_MIN : arr2[cut2 - 1];
        int r1 = cut1 == n ? INT_MAX : arr1[cut1];
        int r2 = cut2 == m ? INT_MAX : arr2[cut2];
        
        if(l1 <= r2 && l2 <= r1)
        {
            return max(l1,l2);
        }
        else if(l1 > r2)
        {
            end = cut1 - 1;
        }
        else
        {
            start = cut1 + 1;
        }
    }
    return 1;
}

int main()
{
    int arr1[] = {2,3,6,7,9};
    int arr2[] = {1,4,8,10};
    int n = sizeof(arr1)/sizeof(arr1[0]);
    int m = sizeof(arr2)/sizeof(arr2[0]);
    int k = 5;
    cout<<"The kth element in final sorted array is : "<<kthElement(arr1,n,arr2,m,k);
    return 0;
}
