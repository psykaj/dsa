#include <iostream>
using namespace std;
// length of the string using char array 
int findLength(char ch[],int size) {
    int length = 0;
    for(int i=0;i<size;i++) {
        if(ch[i] == '\0') {
            break;
        } else {
            length++;
        }
    }
    return length;
}

int main()
{
    char ch[100];
    int n = sizeof(ch)/sizeof(ch[0]);
    cin.getline(ch,100);
    
    int len = findLength(ch,n);
    
    cout<<"The length of the string is : "<<len<<endl;

    return 0;
}
