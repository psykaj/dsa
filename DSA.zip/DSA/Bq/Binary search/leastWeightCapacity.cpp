#include <iostream>
#include <climits>
using namespace std;

//optimal approch
//Tc = O(log n) + O(N) -> [binary search and helper function]
//Sc = O(1)
int helper(int arr[],int N,int mid,int D)
{
    int sum = 0;
    int days = 1;
    
    for(int i=0;i<N;i++)
    {
        if(arr[i] + sum <=  mid)
        {
            sum += arr[i];
        }
        else
        {
            sum = arr[i];
            cout<<"Sum : "<<sum<<endl;
            days++;
        }
    }
    
    cout<<"days : "<<days<<endl;
    
    if(days <= D)
    {
        return true;
    }
    
    return false;
}
  
int binarySearch(int arr[], int N, int D) {
    // code here
    int maxElement = INT_MIN;
    int sum = 0;
    int ans = -1;
    
    for(int i=0;i<N;i++)
    {
        if(arr[i] > maxElement)
        {
            maxElement = arr[i];
        }
        sum += arr[i];
    }
    
    cout<<"Maximum Element in array is : "<<maxElement<<endl;
    cout<<"Sum of array is : "<<sum<<endl;
    
    int start = maxElement;
    int end = sum;
    
    while(start <= end)
    {
        int mid = start + (end - start) / 2;
        
        if(helper(arr,N,mid,D))
        {
            ans = mid;
            end = mid  - 1;
        }
        else
        {
            start = mid + 1;
        }
    }
    return ans;
}
    
int main()
{
    int arr[] = {3,5,4,6,2};
    int n = 5;
    int d = 3;
    int ans = binarySearch(arr,n,d);
    cout<<"The least weight capacity load within d days is : "<<ans<<endl;
    return 0;
}