//Find k element in two sorted arrays
//Brute force approch
#include <iostream>
using namespace std;
//Tc = O(k) -> we iterate total k times so that's why O(K);
//Sc = O(1) -> we dont take any extra space 
int kthelement(int array1[],int array2[],int m,int n,int k)
{
    int i=0;
    int j=0;
    int count = 0;
    int ans = 0;
    
    while(i <n && j<m)
    {
        if(count == k)
        {
            break;
        }
        else if(array1[i] < array2[j])
        {
            ans = array1[i];
            i++;
        }
        else
        {
            ans = array2[j];
            j++;
        }
        count++;
    }
    
    if(count != k)
    {
        if(i != m)
        {
            ans = array1[k-count];
        }
        else
        {
            ans = array2[k-count];
        }
    }
    return ans;
}

int main()
{
    int array1[] = {0};
    int array2[] = {1,4,8,10};
    int m = sizeof(array1)/sizeof(array1[0]);
    int n = sizeof(array2)/sizeof(array2[0]);
    int k = 3;
    cout<<"The element at the kth position in the final sorted array is "<<kthelement(array1,array2,m,n,k);
    return 0;
}
