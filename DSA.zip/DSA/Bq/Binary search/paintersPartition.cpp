#include <iostream>
using namespace std;

bool isPossible(int arr[],int n,int k,int mid)
{
    int paintersCount = 1;
    int person = 0;
    
    for(int i=0;i<n;i++)
    {
        if(person + arr[i] <= mid)
        {
            person += arr[i];
        }
        else
        {
            person++;
            if(person > k || arr[i] > mid)
            {
                return false;
            }
            person += arr[i];
        }
    }
    return true;
}

int paintersPartition(int arr[],int n,int k)
{
    int start = 0;
    int sum = 0;
    
    for(int i=0;i<n;i++)
    {
        sum += arr[i];
    }
    
    int end = sum;
    int ans = -1;
    int mid = start + (end - start) / 2;
    
    
    while(start <= end)
    {
        
        if(isPossible(arr,n,k,mid))
        {
            ans = mid;
            end = mid - 1;
        }
        else
        {
            start = mid + 1;
        }
        mid = start + (end - start) / 2;
    }
    return ans;
}

int main()
{
    int arr[] = {5,5,5,5};
    int n = 4;
    int k = 2;
    cout<<"The paticular painters alloted these much workers : "<<paintersPartition(arr,n,k);
    return 0;
}
