#include <iostream>
using namespace std;

//Brute force approch
//Tc = O(N+M);
//Sc = O(N+M);
//for odd case 
/*int binarySearch(int arr3[],int p)
{
    int start = 0;
    int end = p-1;
    int mid = start + end / 2;
    return arr3[mid];
}

//for even case
//brute force approch
//Tc and Sc is same as above
int binarySearch(int arr3[],int p)
{
    int start = 0;
    int end = p-1;
    int mid = start + end / 2;
    int firstMiddleElement = arr3[mid];
    int secondMiddleElement = arr3[mid+1];
    int ans = (firstMiddleElement + secondMiddleElement)/2;
    return ans;
}

int findMedianOfTwoSortedArray(int arr1[],int n,int arr2[],int m)
{
    int p = n+m;
    int arr3[p];
    
    int i = 0;
    int j = 0;
    int k = 0;
    
    while(i < n && j < m)
    {
        if(arr1[i] < arr2[j])
        {
            arr3[k] = arr1[i];
            i++;
            k++;
        }
        else if(arr2[j] < arr1[i])
        {
            arr3[k] = arr2[j];
            j++;
            k++;
        }
        else
        {
            arr3[k] = arr1[i];
            i++;
            j++;
            k++;
        }
    }
    
    while(i < n)
    {
        arr3[k] = arr1[i];
        i++;
        k++;
    }
    
    while(j < m)
    {
        arr3[k] = arr2[j];
        j++;
        k++;
    }
    
    cout<<"The two sorted array is : ";
    for(int i=0;i<p;i++)
    {
        cout<<arr3[i]<<" ";
    }
    cout<<endl;
    
    int ans = binarySearch(arr3,p);
    
    return ans;
}

int main()
{
    int arr1[] = {1,5,9};
    int n = 3;
    int arr2[] = {2,3,6,7};
    int m = 4;
    int ans = findMedianOfTwoSortedArray(arr1,n,arr2,m);
    cout<<"The median of two sorted array is : "<<ans<<endl;
    return 0;
}*/


//optmise brute force approch
/*#include<bits/stdc++.h>
using namespace std;
//Tc = O(n+m);
//Sc = O(n+m);
float findMedian(int arr1[],int n,int arr2[],int m)
{
    int i=0;
    int j=0;
    int k=0;
    
    int finalArray[n+m];
    
    while(i<n && j<m)
    {
        if(arr1[i] < arr2[j])
        {
            finalArray[k] = arr1[i];
            i++;
            k++;
        }
        else if(arr1[i] > arr2[j])
        {
            finalArray[k] = arr2[j];
            j++;
            k++;
        }
        else
        {
            finalArray[k] = arr2[j];
            i++;
            j++;
            k++;
        }
    }
    
    if(i<n)
    {
        while(i<n)
        {
            finalArray[k] = arr1[i];
            i++;
            k++;
        }
    }
    
    if(j<m)
    {
        while(j<m)
        {
            finalArray[k] = arr2[j];
            j++;
            k++;
        }
    }
    
    n = n+m;
    
    if(n % 2 == 1)
    {
        return finalArray[((n+1)/2)-1];
    }
    else
    {
        return ((float) finalArray[(n/2)-1] + (float) finalArray[(n/2)])/2;
    }
}

int main()
{
    int arr1[] = {1,4,7,10,12};
    int arr2[] = {2,3,6,15};
    int n = sizeof(arr1)/sizeof(arr1[0]);
    int m = sizeof(arr2)/sizeof(arr2[0]);
    cout<<"The median of two sorted array is : "<<fixed<<setprecision(5)<<findMedian(arr1,n,arr2,m);
    return 0;
}*/

//approch 2
//optimise approch 
//Do one more time and do dry run atleast 5 test cases
#include <iostream>
#include <climits>
using namespace std;
//Tc = O(log base2(min(n1,n2)));  //always perform binary search in minimal array 
//Sc = O(1) //we do not use extra space
double findMedianSortedArrays(int arr1[],int n1,int arr2[],int n2) 
{
    //Always apply binary Search on smaller array 
    if(n1 < n2)
    {
        return findMedianSortedArrays(arr2,n2,arr1,n1);
    }
        
    int start = 0;
    int end = n1;
        
    while(start <= end)
    {
        int cut1 = (start + end) >> 1;
        int cut2 = (n1 + n2 + 1) / 2 - cut1; //works for both even/odd case
            
        int left1 = cut1 == 0 ? INT_MIN : arr1[cut1 - 1];
        int left2 = cut2 == 0 ? INT_MIN : arr2[cut2 - 1];
        int right1 = cut1 == n1 ? INT_MAX : arr1[cut1];
        int right2 = cut2 == n2 ? INT_MAX : arr2[cut2];
            
        if(left1 <= right2 && left2 <= right1)
        {
            if((n1+ n2) % 2 == 0)
            {
                return (max(left1,left2) + min(right1,right2)) / 2.0;
            }
            else
            {
                return (max(left1,left2));
            }
        }
        else if(left1 > right2)
        {
            end = cut1 - 1;
        }
        else
        {
            start = cut1 + 1;
        }
    }
    return 0.0;
}

int main()
{
    int arr1[] = {1,3,4,7,10,12};
    int arr2[] = {2,3,6,15};
    int n1 = 6;
    int n2 = 4;
    cout<<"The Median of Two Sorted array is : "<<findMedianSortedArrays(arr1,n1,arr2,n2);
    return 0;
}


