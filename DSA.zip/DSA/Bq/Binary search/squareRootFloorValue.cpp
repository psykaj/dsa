#include <iostream>
#include <math.h>
using namespace std;

//Brute force approch
//Tc = O(root x)
//Sc = O(1);
/*int squareRootOfNumber(int x)
{
    if(x == 1 || x == 0)
    {
        return x;
    }
    
    int i=1;
    int res = 1;
    
    while(res <= x)
    {
        i++;
        res = i*i;
    }
    
    return i-1;
}*/

//Externded Brute force approch
//Tc = O(root x)
//Sc = O(1);
/*int countSqaure(int x)
{
    int sqr = sqrt(x);
    int res = (int)(sqr);
    return res;
}*/

//optimise approch -> using binary search 
//Tc = log(x);
//Sc = O(1);
int binarySearch(int x)
{
    int start = 0;
    int end = x/2;
    int ans;
    
    while(start <= end)
    {
        int mid = start + (end - start)/2;
        
        int sqr = mid * mid;
        
        if(sqr == x)
        {
            return mid;
        }
        else if(sqr < x)
        {
            start = mid + 1;
            ans = mid;
        }
        else
        {
            end = mid - 1;
        }
    }
    return ans;
}

int main()
{
    int x = 165;
    //cout<<squareRootOfNumber(x);
    cout<<binarySearch(x);
    //cout<<countSqaure(x);
    

    return 0;
}
