//book allocation problem using binary search 
// book allocation problem -> search space concept
// maximize minimum problem -> book allocation and painters partition;
// allocate minimum number of pages -> gfg 
// for accumulate function in stl for end 
#include <iostream>
using namespace std;
//optimize approch 
//TC = O(logN) + O(N);
//SC = O(1);
bool isPossible(int arr[],int n,int k,int mid)
{
    int studentCount = 1;
    int pageSum = 0;
    
    for(int i=0;i<n;i++)
    {
        if(arr[i] + pageSum <= mid)
        {
            pageSum += arr[i];
        }
        else
        {
            studentCount++;
            if(studentCount > k || arr[i] > mid)
            {
                return false;
            }
            pageSum = arr[i]; //check pageSum for the another student 
        }
    }
    return true;
}

int bookAllocation(int arr[],int n,int k)
{
    if(n < k)
    {
        return -1;
    }    
        
    int start = 0;
    int sum = 0;
    
    for(int i=0;i<n;i++)
    {
        sum += arr[i];
    }
    
    int end = sum;
    int ans = -1;
    int mid = start + (end - start)/2;
    
    while(start <= end)
    {
        if(isPossible(arr,n,k,mid))
        {
            ans = mid;
            end = mid - 1;
        }
        else
        {
            start = mid + 1;
        }
        mid = start + (end - start)/2;
    }
    return ans;
}

int main()
{
    int arr[] = {10,20,30,40};
    int n = 4;
    int k = 2;
    cout<<bookAllocation(arr,n,k);
    return 0;
}
