#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
//Tc = O(N*M) + [(N*M) log (N*M)]  -> insert element in vector and sort the vector
//Sc = O(N*M) -> taken vector 
void medianOfRowWiseSortedArray(int arr[][3])
{
    vector<int> v;
    
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            v.push_back(arr[i][j]);
        }
    }
    
    sort(v.begin(),v.end());
    
    int n = v.size();
    
    int start = 0;
    int end = n-1;
    int mid = (start + end)/2;
    
    //cout<<v[mid]<<endl;
    return v[mid];
}

int main()
{
    int arr[3][3] = {1,3,6,2,6,9,3,6,9};
    cout<<"The median of row wise sorted array is : "<<medianOfRowWiseSortedArray(arr);
    return 0;
}

//optimise approch
//Tc = log(2^32) [which is 2^9] + O(N) for traversing + log M (to find middle element)
//Tc = O(32 * Row * log(col)); 
//Sc = O(1);
int countSmallerThanEqualToMid(vector<int> &row,int mid)
{
    int start = 0;
    int end = row.size()-1;
    while(start <= end)
    {
        int mid = start + (end - start)/2;
        
        if(row[mid] <= mid) // if mid is bigger than mid index element
        {
            start = mid + 1;
        }
        else
        {
            end = mid - 1;
        }
    }
    return start;
}

int binarySearch(vector<vector<int>> &V)
{
    int n = V.size(); //row
    int m = V[0].size(); //col
    
    int start = 0;
    int end = m-1;
    
    while(start <= end)
    {
        int mid = start + (end - start)/2;
        int count = 0;
        
        for(int i=0;i<n;i++)
        {
            count += countSmallerThanEqualToMid(V[i],mid);
        }
        
        if(count <= (n + m)/2)
        {
            start = mid + 1;
        }
        else
        {
            end = mid - 1;
        }
    }
    return start;
}

int main()
{
    vector<vector<int>> V = {{1,3,6},{2,6,9},{3,6,9}};
    cout<<binarySearch(V);
    return 0;
}

