
//Using binary search
#include <iostream>
#include <math.h>
using namespace std;
//Tc = O(N) -> traversal for loop * Log(M * 10^d) -> using binary search and 
//10^d for the decimal values

//Tc = O(N) * log(M*10^d)
//Sc = O(1)
double multiply(double number,int n)
{
    double ans = 1.0;
    for(int i=1;i<=n;i++)
    {
        ans = ans * number;
    }
    return ans;
}

void getNthRoot(int n,int m)
{
    double start = 1;
    double end = m;
    double eps = 1e-7; 
    
    while((end - start) > eps)
    {
        double mid = (start + end) / 2;
        
        if(multiply(mid,n) < m)
        {
            start = mid;
        }
        else
        {
            end = mid;
        }
    }
    
    //cout<<start<<" "<<end<<endl;
    cout<<n<<" root of "<<m<<" is "<<start<<endl;
}

int main()
{
    int n = 3;
    int m = 27;
    getNthRoot(n,m);

    return 0;
}
