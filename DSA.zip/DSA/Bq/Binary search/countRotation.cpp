//count rotate array 
//Brute force approch
#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
void kRotattion(int arr[],int n)
{
    int min = arr[0];
    int minIndex = 0;
    for(int i=1;i<n;i++)
    {
        if(min > arr[i])
        {
            cout<<"min 1 : "<<min<<endl;
            min = arr[i];
            cout<<"min 2 : "<<min<<endl;
            minIndex = i;
            cout<<"Min Index : "<<minIndex<<endl;
        }
    }
    cout<<minIndex<<endl;
}


int main()
{
    int arr[] = {18,15,21,69,2,3};
    int n = 6;
    kRotattion(arr,n);
    return 0;
}
