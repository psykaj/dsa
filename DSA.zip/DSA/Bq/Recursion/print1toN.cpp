#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N); -> stack space (Computer internal memory)

int count = 0;

void print(int n)
{
    if(count == 5)
    {
        cout<<count<<" ";
        return;
    }
    cout<<count<<" ";
    count++;
    print(n);
    
}

int main()
{
    int n;
    cin>>n;
    
    print(n);

    return 0;
}

//Approch 2
#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N) -> stack space 

void print(int i,int n)
{
    if(i > n)
    {
        return;
    }
    cout<<i<<" ";
    print(i+1,n);
    
}

int main()
{
    int n;
    cin>>n;
    
    print(1,n);

    return 0;
}


//approch 3 (using backtracking)
#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N) -> stack space 

void print(int i,int n)
{
    if(i < 1)
    {
        return;
    }
    print(i-1,n);
    //Printing i after back track
    cout<<i<<" ";
}

int main()
{
    int n;
    cin>>n;
    
    print(n,n);

    return 0;
}

