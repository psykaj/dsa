#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N) -> stack space 

void print(int i,int n)
{
    if(i < 1)
    {
        return;
    }
    cout<<i<<" ";
    print(i-1,n);
    
}

int main()
{
    int n;
    cin>>n;
    
    print(n,n);

    return 0;
}

//Approch 2 (using backtracking)
#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N) -> stack space 

void print(int i,int n)
{
    if(i > n)
    {
        return;
    }
    print(i+1,n);
    
    //Printing i after back track
    cout<<i<<" ";
    
}

int main()
{
    int n;
    cin>>n;
    
    print(1,n);

    return 0;
}
