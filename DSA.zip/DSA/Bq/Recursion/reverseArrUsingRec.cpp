#include <iostream>
using namespace std;

//Approch 1

//Tc = O(N);
//Sc = O(N); -> stack space

//using two varable left & right 
// void swapArr(int arr[],int left,int right)
// {
//     if(left >= right)
//     {
//         return;
//     }
//     swap(arr[left],arr[right]);
//     swapArr(arr,left+1,right-1);
// }


//Approch 2

//Tc = O(N);
//Sc = O(N); -> stack space

//using one variable from starting index
void swapArr(int arr[],int i,int n)
{
    if(i > n/2)
    {
        return;
    }
    swap(arr[i],arr[n-i-1]);
    swapArr(arr,i+1,n);
}

void print(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int arr[5] = {1,2,3,4,5};
    int n = sizeof(arr)/sizeof(arr[0]);
    swapArr(arr,0,n);
    print(arr,n);
    return 0;
}
