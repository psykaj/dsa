#include <iostream>
using namespace std;

//Tc = O(2^n); -> exponential
//Sc = O();

//Multiple recursion calls
int fibonacci(int n)
{
    if(n <= 1)
    {
        return n;
    }
    
    int last = fibonacci(n-1); //first recursion call
    int secondLast = fibonacci(n-2); //second recursion call 
    
    return last + secondLast;
}

int main()
{
    int n;
    cin>>n;
    
    cout<<fibonacci(n);
    
    return 0;
}
