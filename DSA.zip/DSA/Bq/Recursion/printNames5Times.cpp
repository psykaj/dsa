#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N) -> stack space 

void print(int i,int n)
{
    if(i > n)
    {
        return;
    }
    cout<<"Pankaj"<<endl;
    print(i+1,n);
    
}

int main()
{
    int n;
    cin>>n;
    
    print(1,n);

    return 0;
}
