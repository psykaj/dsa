#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N); -> stack space 

//Approch 1 -> funtional way
int fact(int n)
{
    if(n == 0)
    {
        return 1;
    }
    
    return n*fact(n-1);
}

int main()
{
    int n;
    cin>>n;
    
    cout<<"factorial is : "<<fact(n)<<"!";

    return 0;
}
