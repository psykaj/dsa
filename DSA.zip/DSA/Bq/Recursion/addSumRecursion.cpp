#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N); -> stack space 

//Approch 1 -> parameterized way 
void addSum(int i,int sum)
{
    if(i < 1)
    {
        cout<<"Addition is : "<<sum<<endl;
        return;
    }
    
    addSum(i-1,sum+i);
}

int main()
{
    int n;
    cin>>n;
    
    addSum(n,0);

    return 0;
}


//Approch 2

//Tc = O(N);
//Sc = O(N); -> stack space 


// void addSum(int i,int sum)
// {
//     if(i > 5)
//     {
//         cout<<"Addition is : "<<sum<<endl;
//         return;
//     }
    
//     addSum(i+1,sum+i);
// }

// int main()
// {
//     // int n;
//     // cin>>n;
    
//     addSum(0,0);

//     return 0;
// }

#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N); -> stack space 

//Approch 3 -> funtional way
int addSum(int n)
{
    if(n < 1)
    {
        return 0;
    }
    
    return n+addSum(n-1);
}

int main()
{
    int n;
    cin>>n;
    
    cout<<"Addition is : "<<addSum(n);

    return 0;
}

