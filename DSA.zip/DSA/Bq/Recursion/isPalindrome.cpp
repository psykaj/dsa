#include <iostream>
using namespace std;

//Tc = O(N);
//Sc = O(N); -> stack space

//Approch 1 -> parameterized way 
bool isPalindrome(string str,int left,int right)
{
    if(left >= right)
    {
        return true;
    }
    
    if(str[left] != str[right])
    {
        return false;
        
    }
    return isPalindrome(str,left+1,right-1);
}

int main()
{
    string str = "madam";
    int n = str.size();
    int ans = isPalindrome(str,0,n-1);
    if(ans)
    {
        cout<<"The given string is palindrome"<<endl;
    }
    else
    {
        cout<<"The given string is not a palindrome"<<endl;
    }
    return 0;
}
