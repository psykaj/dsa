#include <iostream>
#include <algorithm>
#include <unordered_map>
using namespace std;

//Approch 1 
//Tc = O(Nlogn) + O(N)
//Sc = O(1);
// int findDupilcate(int *arr,int n)
// {
//     sort(arr,arr+n);
//     for(int i=0;i<n;i++)
//     {
//         if(arr[i] == arr[i+1])
//         {
//             return arr[i];
//         }
//     }
//     return 0;
// }

//Approch 2 
//Tc = O(N);
//Sc = O(N);
// int findDupilcate(int arr[],int n)
// {
//     int freq[n+1] = {0};
//     for(int i=0;i<n;i++)
//     {
//         if(freq[arr[i]] == 0)
//         {
//             freq[arr[i]] += 1;
//         }
//         else
//         {
//             return arr[i];
//         }
//     }
//     return -1;
// }

//Approch 3 
//Tc = O(N);
//Sc = O(N);
// void findDupilcate(int *arr,int n)
// {
//     unordered_map<int,int> mp;
//     for(int i=0;i<n;i++)
//     {
//         mp[arr[i]]++;
//     }
    
//     for(auto i:mp)
//     {
//         if(i.second >= 2)
//         {
//             cout<<i.first<<" ";
//         }
//     }
// }

//Approch 4 => slow & fast pointers
//Tc = O(N);
//Sc = O(1);
// int findDupilcate(int *arr,int n)
// {
//     int slow = arr[0];
//     int fast = arr[0];
    
//     do {
//         slow = arr[slow]; // for move slow pointer to 1 step   
//         cout<<"slow pointer : "<<slow<<endl;
//         fast = arr[arr[fast]]; // for move fast pointer to 2 step 
//         cout<<"fast pointer : "<<fast<<endl;
//     } while(slow != fast);
    
//     fast = arr[0];
//     while(slow != fast)
//     {
//         slow = arr[slow];
//         fast = arr[fast];
//     }
//     return fast;
// }

int main()
{
    int arr[] = {2,5,9,6,9,3,8,9,7,1};
    int n = sizeof(arr)/sizeof(arr[0]);
    //findDupilcate(arr,n);
    cout<<findDupilcate(arr,n);
    return 0;
}
