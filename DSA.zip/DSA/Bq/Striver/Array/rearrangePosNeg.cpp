//Approch 1 
#include <iostream>
#include <vector>
using namespace std;
//Tc = O(N) + O(N/2) => O(N);
//Sc = O(N/2) + O(N/2) => O(N) taken 2 vector of half  
// void rearrangePosNeg(int arr[],int n)
// {
//     vector<int> pos;
//     vector<int> neg;
    
//     for(int i=0;i<n;i++)
//     {
//         if(arr[i] < 0)
//         {
//             neg.push_back(arr[i]);
//         }
//         else
//         {
//             pos.push_back(arr[i]);
//         }
//     }
    
//     for(int i=0;i<n/2;i++)
//     {
//         arr[i*2] = pos[i];
//         arr[i*2+1] = neg[i];
//     }
// }

//Tc = O(N);
//Sc = O(N);
vector<int> rearrangePosNeg(vector<int> &arr)
{
    int n = arr.size();
    
    vector<int> ans(n,0);
    
    int posIndex = 0;
    int negIndex = 1;
    
    for(int i=0;i<n;i++)
    {
        if(arr[i] < 0)
        {
            ans[negIndex] = arr[i];
            negIndex += 2;
        }
        else
        {
            ans[posIndex] = arr[i];
            posIndex += 2;
        }
    }
    return ans;
}

void printArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    // int arr[] = {1,2,-4,-5};
    // int n = sizeof(arr)/sizeof(arr[0]);
    // rearrangePosNeg(arr,n);
    vector<int> arr = {1,2,-4,-5};
    vector<int> ans = rearrangePosNeg(arr);
    //printArray(arr,n);
    for(int i=0;i<ans.size();i++)
    {
        cout<<ans[i]<<" ";
    }
    cout<<endl;
    return 0;
}
