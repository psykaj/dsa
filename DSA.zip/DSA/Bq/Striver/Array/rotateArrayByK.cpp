#include <iostream>
using namespace std;

//Tc = O(k) + O(k-n) + O(k);
//Sc = O(k) -> taken temp array of k size 
// void leftRotateByK(int arr[],int n,int k)
// {
//     if(n == 0)
//     {
//         return;
//     }
    
//     //If k is smaller than n then same value will appear
//     k = k % n;
//     //cout<<k<<endl;
    
//     int temp[k];
    
//     for(int i=0;i<k;i++)
//     {
//         temp[i] = arr[i];
//     }
    
//     for(int i=k;i<n;i++)
//     {
//         arr[i-k] = arr[i];
//     }
    
//     for(int i=n-k;i<n;i++)
//     {
//         arr[i] = temp[i-(n-k)];
//     }
// }

// void printArray(int arr[],int n)
// {
//     for(int i=0;i<n;i++)
//     {
//         cout<<arr[i]<<" ";
//     }
//     cout<<endl;
// }

//approch 2 -> optimal 
//Tc = O(k) + O(n-k) + O(n) = O(2*n) -> O(n);
//Sc = O(1)
// void reverse(int arr[],int start,int end)
// {
//     while(start <= end)
//     {
//         int temp = arr[start];
//         arr[start] = arr[end];
//         arr[end] = temp;
//         start++;
//         end--;
//     }
// }

// void leftRotateByK(int arr[],int n,int k)
// {
//     if(n == 0)
//     {
//         return;
//     }
    
//     k = k % n;
    
//     reverse(arr,0,k-1);
    
//     reverse(arr,k,n-1);
    
//     reverse(arr,0,n-1);
// }

// void printArray(int arr[],int n)
// {
//     for(int i=0;i<n;i++)
//     {
//         cout<<arr[i]<<" ";
//     }
//     cout<<endl;
// }

// int main()
// {
//     int arr[] = {1,2,3,4,5,6,7};
//     int n = sizeof(arr)/sizeof(arr[0]);
//     int k = 3;
//     cout<<"Before rotate the array is : ";
//     printArray(arr,n);
//     leftRotateByK(arr,n,k);
//     cout<<"After rotate the arrays is : ";
//     printArray(arr,n);
//     return 0;
// }
