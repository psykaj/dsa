//Approch 1
//Tc = O(logn);
//Sc = O(1);
/*#include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    
    int dummy = n;
    int m = 0;
    
    while(n>0)
    {
        //Extract last digit from n;
        int lastDigit = n%10;
        //Append last digit into m 
        m = m*10 + lastDigit;
        //remove last digit from n 
        n = n / 10;
    }
    
    if(m == dummy)
    {
        cout<<"Number is panlindrome"<<endl;
    }
    else
    {
        cout<<"Number is not a panlindrome"<<endl;
    }

    return 0;
}*/


/*//Tc = O(N) , Sc = O(1)
//Find all palindrome number in a given range
#include <iostream>
using namespace std;
bool isPalindrome(int n)
{
    int dummy = n;
    int m = 0;
    while(n>0)
    {
        //Extract lastDigit from n 
        int lastDigit = n%10;
        //add it into the m 
        m = m * 10 + lastDigit;
        //Remove last digit from n 
        n = n / 10;
    }
    
    if(m == dummy)
    {
        return true;
    }
    return false;
}

int main()
{
    int minNumber = 100,maxNumber = 150;
    for(int i=minNumber;i<=maxNumber;i++)
    {
        if(isPalindrome(i))
        {
            cout<<i<<" ";
        }
    }
    return 0;
}
*/