//Tc = O(N);
//Sc = O(1);
#include <iostream>
using namespace std;
bool automorphic(int num)
{
    int sq = num * num;
    
    while(num > 0)
    {
        if(num%10 != sq%10)
        {
            return false;
        }
        num = num / 10;
        sq = sq / 10;
    }
    return true;
}

int main()
{
    int n;
    cin>>n;
    
    if(automorphic(n))
    {
        cout<<"automorphic number";
    }
    else
    {
        cout<<"Not a automorphic number";
    }
    return 0;
}
