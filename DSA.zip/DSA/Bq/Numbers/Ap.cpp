#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int main()
{
    int n,a,d;
    cin>>n>>a>>d;
    int sum = 0;
    for(int i=1;i<=n;i++)
    {
        sum += a;
        cout<<"sum : "<<sum<<" , ";
        a += d;
        cout<<"a : "<<a<<" ";
    }
    cout<<endl;
    cout<<a<<endl;
    cout<<sum<<endl;
    return 0;
}

//Optimal Approch
//Tc = O(1);
//Sc = O(1);
//sum = (n / 2.0) * (2.0 * a + (n - 1) * d);