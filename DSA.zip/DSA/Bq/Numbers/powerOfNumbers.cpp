#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    //Tc = O(N);
    //Sc = O(1);
    /*int n,p;
    cin>>n>>p;
    int ans = 1;
    for(int i=0;i<p;i++)
    {
        ans = ans * n;
    }
    cout<<ans<<endl;*/
    
    //Tc = O(log n)
    //Sc = O(1);
    /*int n,p;
    cin>>n>>p;
    int ans;
    ans = pow(n,p);
    cout<<ans;*/
    return 0;
}
