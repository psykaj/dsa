//Abundant Number or not 
#include <iostream>
using namespace std;
int main()
{
    //Brute force
    /*//Tc = O(N);
    //Sc = O(1);
    int n;
    cin>>n;
    
    int sum = 0;
    
    for(int i=1;i<=n;i++)
    {
        if(n % i == 0)
        {
            sum = sum + i;
        }
    }
    cout<<"Sum : "<<sum<<endl; 
    
    int res = sum - n;
    
    if(res>n)
    {
        cout<<"Abundant Number";
    }
    else
    {
        cout<<"Not a Abundant Number";
    }*/

    //Optimal approch
    /*//Tc = O(sqrt(n));
    //Sc = O(1);
    int n = 12;
    int sum = 0;
    //(sqrt) = lagane se vo half iteration mai check kar leta hai
    for (int i = 1; i <= sqrt(n); i++) { 
        if (n % i == 0) {
            if (n / i == i) {
                sum += i;
                cout<<"if wala sum : "<<sum<<endl;
            }
            else {
                sum += i;
                cout<<"else ka fist sum : "<<sum<<endl;
                sum += n / i;
                cout<<"else ka second sum : "<<sum<<endl;
            }
        }
    }
    cout<<"Total Sum : "<<sum<<endl;
    sum -= n;
    cout<<"Sum after minus : "<<sum<<endl;
    if (sum > n) {
        cout << "Abundant Number" << "\n";
    }
    else {
        cout << "Not Abundant Number" << "\n";
    }*/

    return 0;
}
