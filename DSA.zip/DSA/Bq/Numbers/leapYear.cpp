//Tc = O(1);
//Sc = O(1);
/*#include <iostream>
using namespace std;
bool checkYear(int n)
{
    if(n % 400 == 0)
    {
        return true;
    }
    
    if(n % 4 == 0)
    {
        return true;
    }
    
    if(n % 100 == 0)
    {
        return false;
    }
    
    return false;
}

int main()
{
  int n;
  cin>>n;
  if(checkYear(n))
  {
    cout<<"It is a leap year";  
  }
  else
  {
    cout<<"It is not a leap year";
  }
  return 0;
}*/

//Optimal Approch
//Tc = O(1) , Sc = O(1);
/*#include <iostream>
using namespace std;
int main()
{
  int n;
  cin>>n;
  if((n % 100 != 0 && n % 4 == 0) || (n % 400 == 0))
  {
    cout<<"It is a leap year";  
  }
  else
  {
    cout<<"It is not a leap year";
  }
  return 0;
}*/
