//Permutations in which N people can occupy R seats
#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int fact(int n)
{
    int ans = 1;
    for(int i=1;i<=n;i++)
    {
        ans *= i;
    }
    return ans;
}

int main()
{
    int n = 5 , r = 3;
    int numerator = fact(n);
    int denominator = fact(n-r);
    cout<<numerator/denominator;
    return 0;
}
