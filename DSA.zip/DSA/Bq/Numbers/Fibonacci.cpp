//Brute force
//Tc = O(N);
//Sc = O(1);
/*#include <iostream>
using namespace std;
int main()
{
  int n;
  cin>>n;
  
  int ft = 0;
  int st = 1;
  cout<<ft<<" "<<st<<" ";
  
  int sum = ft + st;
  for(int i=2;i<n;i++)
  {
    int sum = ft + st;
    cout<<sum<<" ";
    ft = st;
    st = sum;
  }
  return 0;
}*/
