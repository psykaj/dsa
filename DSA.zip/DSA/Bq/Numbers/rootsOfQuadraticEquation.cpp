#include <iostream>
#include <math.h>
using namespace std;
void roots(int a,int b,int c)
{
    //Tc = O(N);
    // sc = O(1);
    int d = b*b - 4*a*c;
    cout<<d<<endl;
    double sqrt_val = sqrt(abs(d));
    
    if(d > 0)
    {
        double root1 = (double) (-b + sqrt_val)/(2*a);
        double root2 = (double) (-b - sqrt_val)/(2*a);
        cout<<root1<<" "<<root2<<endl;
    }
    else if(d == 0)
    {
        double root1 = -(double)b / (2 * a);
        double root2 = -(double)b / (2 * a);
        cout<<root1<<" "<<root2<<endl;
    }
    else
    {
        double root1 = -(double)b / (2 * a);
        double root2 = -(double)b / (2 * a);
        cout<<root1<<" "<<sqrt_val;
        cout<<root2<<" "<<sqrt_val;
    }
}

int main()
{
    int a = 1, b = -3, c = -10;
    roots(a,b,c);
    return 0;
}
