//Replace all 0 with 1; 
#include <iostream>
using namespace std;
int main()
{
    //Tc = O(N);
    //Sc = O(1);
    int n;
    cin>>n;
    
    int sum = 0;
    int temp = 1;
    
    while(n>0)
    {
        int lastDigit = n % 10;
        if(lastDigit == 0)
        {
            lastDigit = 1;
        }
        sum = sum + lastDigit * temp; 
        n = n / 10;
        temp = temp * 10;
    }
    
    cout<<"the answer of n is : "<<sum<<endl;

    return 0;
}
