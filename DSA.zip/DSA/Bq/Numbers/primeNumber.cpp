//Find all palindrome number in a given range
/*#include <iostream>
using namespace std;
bool isPrime(int n)
{
    for(int i=2;i<n;i++)
    {
        if(n % i == 0)
        {
            return false;
        }
    }
    return true;
}

int main()
{
    int n;
    cin>>n;
    
    bool ans = isPrime(n);
    
    if(n != 1 && ans == true)
    {
        cout<<"Number is prime";
    }
    else
    {
        cout<<"Number is not a prime";
    }
    return 0;
}*/


/*Tc = O(root n); Sc = O(1)
Optimize Approch
#include <iostream>
#include <math.h>
using namespace std;
bool isPrime(int n)
{
    for(int i=2;i<sqrt(n);i++)
    {
        if(n % i == 0)
        {
            return false;
        }
    }
    return true;
}

int main()
{
    int n;
    cin>>n;
    
    bool ans = isPrime(n);
    
    if(n != 1 && ans == true)
    {
        cout<<"Number is prime";
    }
    else
    {
        cout<<"Number is not a prime";
    }
    return 0;
}
*/