//Tc = O(N) , Sc = O(1);
/*#include <iostream>
#include <climits>
using namespace std;
int main()
{
  int n;
  cin>>n;
  int sum = 0;
  int mini = INT_MAX;
  int maxi = INT_MIN;
  while(n>0)
  {
    int lastDigit = n % 10;
    if(mini > lastDigit)
    {
        mini = lastDigit;
    }
    if(maxi < lastDigit)
    {
        maxi = lastDigit;
    }
    sum = sum * 10 + lastDigit;
    n = n/10;
  }
  cout<<"Reversed Number : "<<sum<<endl;
  cout<<"Minimum Number : "<<mini<<endl;
  cout<<"Maximum Number : "<<maxi<<endl;
  return 0;
}*/

//Tc = O(log n)
//Sc = O(1);
/*#include<bits/stdc++.h>
using namespace std;
void MinMax(int n)
{
    int d,mini=INT_MAX,maxi=INT_MIN;
    while(n!=0)
    {
        d=n%10;
        mini = min(mini,d);
        maxi=max(maxi,d);
        n=n/10;
    }
    
    cout<<"The minimum number is: "<<mini<<"\n"
        <<"The maximum number is: "<<maxi;
}

int main()
{
    int n = 4726;
    MinMax(n);
    return 0;
}*/

