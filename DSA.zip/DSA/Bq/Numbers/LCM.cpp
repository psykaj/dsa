//LCM(Least Common Multiple)
#include <iostream>
#include <climits>
using namespace std;
//brute force
//Tc = O(n);
//Sc = O(1);
/*int main()
{
    int num1,num2;
    cin>>num1>>num2;
    
    int mini = min(num1,num2);
    int gcd;
    for(int i=1;i<=mini;i++)
    {
        if(num1 % i == 0 && num2 % i == 0)
        {
            gcd = i;
        }
    }
    int lcm = (num1*num2)/gcd;
    cout<<lcm<<endl;
    return 0;
}*/


//Optimal approch
//Tc = O(log thitha min(num1,num2)) where thitha = 1.61
//Sc = O(1)
/*int gcd(int num1,int num2)
{
    if(num2 == 0)
    {
        return num1;
    }
    return gcd(num2,num1%num2);
}

int main()
{
    int num1,num2;
    cin>>num1>>num2;
    
    int g = gcd(num1,num2);
    
    int lcm = (num1*num2)/g;
    
    cout<<lcm;

    return 0;
}*/
