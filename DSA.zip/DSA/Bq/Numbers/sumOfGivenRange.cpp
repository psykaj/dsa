//Find the sum of numbers in the given range 
#include <iostream>
using namespace std;
int main()
{
    //Brute force
    /*//Tc = O(N);
    //sc = O(1);
    int left,right;
    cin>>left>>right;
    int sum = 0;
    for(int i=left;i<=right;i++)
    {
        sum = sum + i;
    }
    cout<<sum<<endl;*/
    
    //Optimal Approch
    //Tc = O(1);
    //Sc = O(1);
    int l = 2, r = 7;
    //sum(1 to r) - sum(1 to l-1)
	int ans = (r * (r + 1)) / 2 - ((l - 1) * (l)) / 2; //formula
	cout << "The sum of the numbers in the given range is "<<ans;

    return 0;
}
