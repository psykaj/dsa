//brute force 
//Tc = O(N)
//Sc = O(1)
/*#include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    
    int sum = 0;
    for(int i=1;i<n;i++)
    {
        if(n%i == 0)
        {
            sum += i;
        }
    }
    
    if(sum == n)
    {
        cout<<n<<" is a perfect number"<<endl;
    }
    else
    {
        cout<<n<<" is not a perfect number"<<endl;
    }
    
    return 0;
}*/

//Approch 2
//Tc = O(root-N)
//Sc = O(1)
/*#include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    
    int sum = 0;
    for(int i=1;i*i<=n;i++)
    {
        if(n%i == 0)
        {
            if(i*i == n || i == 1)
            {
                sum += i;
            }
            else
            {
                sum = sum + i + n/i;
            }
        }
    }
    
    if(sum == n)
    {
        cout<<n<<" is a perfect number"<<endl;
    }
    else
    {
        cout<<n<<" is not a perfect number"<<endl;
    }
    
    return 0;
}*/

