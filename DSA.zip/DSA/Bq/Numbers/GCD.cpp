//The greatest common divisor (GCD) of two or more numbers 
//is the greatest common factor number that divides them, exactly. 
//It is also called the highest common factor (HCF). 
//For example, the greatest common factor of 15 and 10 is 5, 
//since both the numbers can be divided by 5.
//Tc = O(N);
//Sc = O(1);
//Brute force
/*#include <iostream>
#include <climits>
using namespace std;
int main()
{
    int num1,num2;
    cin>>num1>>num2;
    
    int miniNum = min(num1,num2);
    int ans;
    for(int i=1;i<=miniNum;i++)
    {
        if(num1 % i == 0 && num2 % i == 0)
        {
            ans = i;
        }
    }
    cout<<ans;
    return 0;
}*/

//Optimal Approch
//Using Euclidean’s theorem.
//Tc = O(lof titha min(a,b));
//Sc = O(1);
/*#include <iostream>
#include <climits>
using namespace std;

int gcd(int num1,int num2)
{
    cout<<"num1 : "<<num1<<" "<<"num2 : "<<num2<<endl;
    if(num2 == 0)
    {
        return num1;
    }
    return gcd(num2,num1%num2);
}

int main()
{
    int num1,num2;
    cin>>num1>>num2;
    
    cout<<gcd(num1,num2);
    
    return 0;
}*/


