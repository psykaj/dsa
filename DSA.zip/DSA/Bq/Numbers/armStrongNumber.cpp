//Tc = O(N);
//Sc = O(1);
#include <iostream>
#include <math.h>
using namespace std;
bool armStrong(int n)
{
    int originalNumber = n;
    int temp = n;
    int count = 0;
    
    //getCount
    while(temp != 0)
    {
        count++;
        temp = temp/10;
    }
    
    int sumPower = 0;
    
    while(n != 0)
    {
        int lastDigit = n % 10;
        sumPower += pow(lastDigit,count);
        n = n/10;
    }
    
    if(originalNumber == sumPower)
    {
        return true;
    }
    return false;
}


int main()
{
    int n;
    cin>>n;
    
    if(armStrong(n))
    {
        cout<<"ArmStrong Number";
    }
    else
    {
        cout<<"Not an ArmStrong Number";
    }
    
    return 0;
}
