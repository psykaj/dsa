
//Tc = O(N*M); N for traverse while loop and M is for factorial for loop
//Sc = O(1); did not use any spaces
#include <iostream>
using namespace std;
int fact(int number)
{
    int res = 1;
    for(int i=1;i<=number;i++)
    {
        res = res * i;
    }
    return res;
}

int strongNo(int num)
{
    int sum = 0;
    while(num>0)  
    {
        int lastDigit = num % 10;
        sum = sum + fact(lastDigit);
        num = num / 10;
    }
    return sum;
}

int main()
{
    int n;
    cin>>n;
    
    int ans = strongNo(n);
    cout<<"The output of ans is : "<<ans<<endl;
    
    if(ans == n && n != 0)
    {
        cout<<"Yes it is a strong number";
    }
    else
    {
        cout<<"No , it is not a strong number";
    }
    return 0;
}
