//Harshad Number OR Niven Number
#include <iostream>
using namespace std;
int main()
{
    /*//Tc = O(N);
    //Sc= O(1);
    int n;
    cin>>n;
    
    int sum = 0;
    
    string str = to_string(n); //n converted into string using to_string
    int strSize = str.length();
    
    for(int i=0;i<strSize;i++)
    {
        sum = sum + (str[i] - '0');
    }
    cout<<sum<<endl;
    cout<<n<<endl;
    
    if(n % sum == 0)
    {
        cout<<"Harshad Number";
    }
    else
    {
        cout<<"Not a Harshad Number";
    }*/
    
    
    
    /*//Tc = O(N);
    //Sc = O(1);
    int sum = 0;
    int temp = n;
    
    while(temp>0)
    {
        int lastDigit = temp % 10;
        sum = sum + lastDigit;
        temp = temp / 10;
    }
    
    cout<<sum<<endl;
    cout<<n<<endl;
    
    if(n % sum == 0)
    {
        cout<<"Harshad Number";
    }
    else
    {
        cout<<"Not a Harshad Number";
    }*/

    return 0;
}
