//Tc = O(N);
//Sc = O(1);
//Brute force
/*#include <iostream>
using namespace std;
int main()
{
  int n;
  cin>>n;
  
  int mul = 1;
  
  for(int i=1;i<=n;i++)
  {
    mul *= i; 
  }
  cout<<mul<<"!"<<endl;
  return 0;
}*/

// Optimal Approch
// Tc = O(K);
// Sc = O(1);
/*#include <iostream>
#include <vector>
using namespace std;

vector<int> ans;
int prd = 1;

void fact(int n,int i)
{
    prd = prd * i;
    if(prd > n)
    {
        return;
    }
    ans.push_back(prd);
    fact(n,i+1);
}

vector<int> factorialNum(int n)
{
    fact(n,1);
    return ans;
}

void printVector(vector<int> ans)
{
    for(int i=0;i<ans.size();i++)
    {
        cout<<ans[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int n;
    cin>>n;
    
    factorialNum(n);
    
    printVector(ans);

    return 0;
}*/
