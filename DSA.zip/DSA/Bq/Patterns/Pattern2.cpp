#include <iostream>
using namespace std;
int main()
{
    int n = 4;
    for(int i=1;i<=2*n;i++)
    {
         for(int j=1;j<=i;j++)
        {
            cout<<j;
        }
        
        for(int j=2*n-i-1;j>=1;j--)
        {
            cout<<" ";
        }
        
        for(int j=i;j>=1;j--)
        {
            cout<<j;
        }
        
        cout<<endl;
    }

    return 0;
}
