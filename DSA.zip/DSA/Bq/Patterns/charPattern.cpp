#include <iostream>
using namespace std;
int main()
{
    int n = 5;
    //Pattern 1
    /*for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=i;j++)
        {
            cout<<(char) (j+64);
        }
        cout<<endl;
    }*/
    
    //Patterm 2
    /*for(int i=n;i>=1;i--)
    {
        for(int j=i;j>=1;j--)
        {
            cout<<(char) (j+64);
        }
        cout<<endl;
    }*/
    
    //pattern 3
    /*for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=i;j++)
        {
            cout<<(char) (i+64);
        }
        cout<<endl;
    }*/
    
    //pattern 4
    /*for(int i=1;i<=5;i++)
    {
        for(int j=5-i;j>=1;j--)
        {
            cout<<" ";
        }
        
        for(int j=1;j<=i;j++)
        {
            cout<<(char) (j+64);
            //cout<<j;
        }
        
        for(int j=i-1;j>=1;j--)
        {
            cout<<(char) (j+64);
            //cout<<j;
        }
        cout<<endl;
    }*/
    
    //pattern 5
    /*for(int i=0;i<n;i++)
    {
        for(int j=n-i;j<=n;j++)
        {
            cout<<(char) (j+64)<<" ";
        }
        cout<<endl;
    }*/
    
    return 0;
}
