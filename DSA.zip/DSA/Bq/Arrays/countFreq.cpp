//Brute Force
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(N*N); nested loops
//Sc = O(N); extra vector
void freqArr(int arr[],int n)
{
    vector<bool> visited(n,false);
    int count = 0;
    
    for(int i=0;i<n;i++)
    {
        if(visited[i] == true)
        {
            continue;
        }
        count = 1;
        for(int j=i+1;j<n;j++)
        {
            if(arr[i] == arr[j])
            {
                count++;
                visited[j] = true;
            }
        }
        cout<<arr[i]<<" "<<count<<endl;
    }
}

int main()
{
    int arr[]={10,5,10,15,10,5};
    int n=sizeof(arr)/sizeof(arr[0]);
    freqArr(arr,n);
    return 0;
}*/


//Optimise solution
#include <bits/stdc++.h>
using namespace std;
//Tc = O(N);
//Sc = O(1);
void freqArr(int arr[],int n)
{
    unordered_map<int,int> m;
    for(int i=0;i<n;i++)
    {
        m[arr[i]]++;
    }
    
    for(auto x : m)
    {
        cout<<x.first<<" "<<x.second<<endl;
    }
}

int main()
{
    int arr[]={10,5,10,15,10,5};
    int n=sizeof(arr)/sizeof(arr[0]);
    freqArr(arr,n);
    return 0;
}
