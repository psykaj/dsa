int maxProdSubArray(int arr[],int n)
{
    int maxi = INT_MIN;
    // traversing from front
    int prefix = 1;
    // travsersing from back
    int suffix = 1;
    
    for(int i=0;i<n;i++)
    {
        if(prefix == 0)
        {
            prefix = 1;
        }
        
        if(suffix == 0)
        {
            suffix = 1;
        }
        
        prefix = prefix * arr[i];
        suffix = suffix * arr[n-i-1];
        
        maxi = max(maxi,max(prefix,suffix));
    }
    return maxi;
}

int main()
{
    int arr[] = {1,2,-3,0,-4,-5};
    int n = sizeof(arr)/sizeof(arr[0]);
    int ans = maxProdSubArray(arr,n);
    cout<<"The maximum product of sub array : "<<ans<<endl;

    return 0;
}