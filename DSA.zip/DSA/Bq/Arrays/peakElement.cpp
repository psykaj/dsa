#include <iostream>
using namespace std;
//Brute force 
//Tc = O(N);
//Sc = O(1);
int  peakElement(int arr[],int n)
{
    //Case 1
    if(arr[0] >= arr[1])
    {
        return arr[0];
    }
    
    //Case 2
    for(int i=1;i<n-1;i++)
    {
        if(arr[i] >= arr[i-1] && arr[i] >= arr[i+1])
        {
            return arr[i];
        }
    }

    //Case 3
    return arr[n-1];
}

int main()
{
    int arr[] = {3, 5, 4, 1, 1};
    int n = sizeof(arr)/sizeof(arr[0]);
    cout<<"Peak Element in an array is : "<<peakElement(arr,n)<<endl;
    return 0;
}

//optimize approch
//Tc = O(logn);
//Sc = O(1);
/*int binarySearch(int arr[],int n)
{
    int start = 0;
    int end = n-1;
    int mid = start + (end - start)/2;
    
    while(start <= end)
    {
        //first case 
        if(mid == 0)
        {
            if(arr[0] > arr[1])
            {
                return arr[0];
            }
            else
            {
                return arr[1];
            }
        }
        
        //Last case 
        if(mid == n-1)
        {
            if(arr[n-1] >= arr[n-2])
            {
                return arr[n-1];
            }
            else
            {
                return arr[n-2];
            }
        }
        
        //middle case 
        if(arr[mid] >= arr[mid-1] && arr[mid] >= arr[mid + 1])
        {
            return arr[mid];
        }
        else if(arr[mid] < arr[mid-1])
        {
            end = mid - 1;
        }
        else
        {
            start = mid + 1;
        }
        mid = start + (end - start)/2;
    }
    
    //first case 
    return arr[start];
}

int main()
{
    int arr[] = {3, 5, 4, 1, 1};
    int n = sizeof(arr)/sizeof(arr[0]);
    cout<<"Peak Element in an array is : "<<binarySearch(arr,n)<<endl;
    return 0;
}*/

