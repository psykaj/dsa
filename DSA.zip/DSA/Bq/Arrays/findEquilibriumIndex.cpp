//Brute force approch
#include <iostream>
using namespace std;

//Tc = O(N*N);
//Sc = O(1);

int findEquilibrium(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        int leftSum = 0;
        for(int j=0;j<i;j++)
        {
            leftSum += arr[j];
        }
        
        int rightSum = 0;
        for(int j=i+1;j<n;j++)
        {
            rightSum += arr[j];
        }
        
        if(rightSum == leftSum)
        {
            return i;
        }
    }
    return -1;
}

int main()
{
    int arr[] = {2,3,-1,8,4};
    int n = sizeof(arr)/sizeof(arr[0]);
    cout<<"The Equilibrium of the index in a array is : "<<findEquilibrium(arr,n)<<endl;
    return 0;
}


//optimise approch
#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int findEquilibriumIdx(int arr[],int n)
{
    int leftSum = 0;
    int rightSum  = 0;
    int totalSum = 0;
    for(int i=0;i<n;i++)
    {
        totalSum += arr[i];
    }
    rightSum = totalSum;
    for(int i=0;i<n;i++)
    {
        rightSum -= arr[i];
        if(leftSum == rightSum)
        {
            return i;
        }
        leftSum += arr[i];
    }
    return -1;
}

int main()
{
    int n = 5;
    int arr[] = {2, 3, -1, 8, 4};
    int equilibriumidx = findEquilibriumIdx(arr, n);
    cout << "The equilibrium index is : " << equilibriumidx << endl;
    return 0;
}
