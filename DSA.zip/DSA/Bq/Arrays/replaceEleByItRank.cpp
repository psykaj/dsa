#include<bits/stdc++.h>
using namespace std;
//Replace Element By its Rank

//Tc = O(N) + NlogN + O(N) 
//1) O(N) [is copying element into duplicate array]
//2) NlogN [sorting duplicate array element]
//3) O(N) [for printing its rank]
//Sc = O(N + N) [for creating duplicate array and creating Hashmap]  
void replaceEleByItRank(int arr[],int n)
{
    int dup[n];
    int temp = 1;
    //copy array Element into dummy array
    for(int i=0;i<n;i++)
    {
        dup[i] = arr[i];
    }
    
    sort(dup,dup+n);
    
    map<int,int> m;
    for(int i=0;i<n;i++)
    {
        //dup array sorted so sequence mai map mai jayega
        //m(2,1),m(6,2),m(15,3),m(20,4),m(26,5),m(98,6)
        //in map = (key) = dup array Element
        //in map = (value) = temp value
        //then increment temp
        if(m[dup[i]] == 0)
        {
            m[dup[i]] = temp;
            temp++;
        }
    }
    
    //then map k ander original Element se dup array ka value print kar(temp) denge 
    for(int i=0;i<n;i++)
    {
        cout<<m[arr[i]]<<" ";
    }
}

int main()
{
    int n = 6;
	int arr[n] = {20, 15, 26, 2, 98, 6};
	/*Tc = O(N)2;
    Sc = O(N) (taken set)
    for(int i=0;i<n;i++)
	{
	    set<int> s;
	    for(int j=0;j<n;j++)
	    {
	        if(arr[j] < arr[i])
	        {
	            s.insert(arr[j]);
	        }
	    }
	    cout<<s.size()+1<<" ";
	}*/
	replaceEleByItRank(arr,6);

    return 0;
}
