/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(NlogN) + O(N);
//Sc = O(1);
int dup(int arr[],int n)
{
    int i = 0;
    for(int j=i+1;j<n;j++)
    {
        if(arr[i] != arr[j])
        {
            i++;
            arr[i] = arr[j];
        }
    }
    return i+1;
}

int main()
{
    int arr[]={4, 3, 9, 2, 4, 1, 10, 89, 34 , 3 , 2 , 1 , 10 , 34 , 89};
    int n=sizeof(arr)/sizeof(arr[0]);
    sort(arr,arr+n);
    int k = dup(arr,n);
    for(int i=0;i<k;i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}*/


//Remove duplicate in an unsorted array 
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(N) + O(N) = O(N); first O(N) is for iteration and other O(N) is for search in hashmap
//Sc = O(N); using one hashmap
void dup(int arr[],int n)
{
    map<int,int> m;
    for(int i=0;i<n;i++)
    {
        //if it is a unique element
        if(m.find(arr[i]) == m.end())
        {
            cout<<arr[i]<<" ";
            m[arr[i]]++;
        }
    }
}

int main()
{
    int arr[]={4, 3, 9, 2, 4, 1, 10, 89, 34 , 3 , 2 , 1 , 10 , 34 , 89};
    int n=sizeof(arr)/sizeof(arr[0]);
    dup(arr,n);
    return 0;
}*/

