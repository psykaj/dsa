#include <iostream>
using namespace std;

//Brute force approch
//Tc = O(N);
//Sc = O(1);
/*int seachEleInSortedRotetedArray(int arr[],int n,int target)
{
    for(int i=0;i<n;i++)
    {
        if(arr[i] == target)
        {
            return i;
        }
    }
    return -1;
}*/


//Optimize apprich
//Tc = O(Logn);
//Sc = O(1);
int binarySearch(int arr[],int start,int end,int target)
{
    //If start is greater than end 
    if(start > end)
    {
        return -1;
    }
    
    int mid = start + (end - start)/2;
    
    if(arr[mid] == target)
    {
        return mid;
    }
    
    //if start is equal to mid and end is equal to mid 
    if(arr[start] == arr[mid] && arr[end] == arr[mid])
    {
        start++;
        end--;
        return binarySearch(arr,start,end,target);
    }
    
    //if first half is sorted 
    if(arr[start] <= arr[mid])
    {
        if(arr[start] <= target && arr[mid] >= target)
        {
            //Recursion
            return binarySearch(arr,start,mid-1,target);
        }
        else
        {
            return binarySearch(arr,mid+1,end,target);
        }
    }
    
    //if first half is not sorted then  
    // [mid -> end]  second half must be sorted 
    if(arr[end] >= arr[mid])
    {
        if(arr[end] >= target && arr[mid] <= target)
        {
            return binarySearch(arr,mid+1,end,target);
        }
        else
        {
            return binarySearch(arr,start,mid-1,target);
        }
    }
    return -1;
}

int main()
{
    int arr[] = {3, 3, 1, 2, 3, 3};
    int n = sizeof(arr)/sizeof(arr[0]);
    int target = 3;
    //cout<<"The element is present in an array index is : "<<seachEleInSortedRotetedArray(arr,n,target)<<endl;
    cout<<"The element is present in an array index is : "<<binarySearch(arr,0,n-1,target)<<endl;
    return 0;
}
