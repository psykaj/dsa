#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n = 5;
    int arr[][2] = {{1, 2}, {2, 1}, {3, 4}, {4, 5}, {5, 4}}; 
    //unordered_map<int,int> m;
    /*Tc = O(N)2 
    Sc = O(1)
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(arr[j][0] == arr[i][1] && arr[j][1] == arr[i][0])
            {
                cout<<"("<<arr[i][1]<<" "<<arr[i][0]<<")"<<" ";
                break;
            }
        }
    }
    return 0;
}*/

//print these for understanding purpose
//cout<<arr[j][0]<<" "<<arr[i][1]<<" "<<arr[j][1]<<" "<<arr[i][0]<<endl;


/*#include<bits/stdc++.h>
using namespace std;
//Tc = O(N);
//Sc = O(N);
int main()
{
    int n = 5;
    int arr[5][2] = {{1, 2}, {2, 1}, {3, 4}, {4, 5}, {5, 4}};
    unordered_map<int, int>m;
    cout<<"The Symmetric Pairs are: ";
    for (int i = 0; i < n; i++) 
    {
        int first = arr[i][0]; //1
        int second = arr[i][1]; //2
        
        //if these value is previouly store in map then print
        //check {second,first} exist in the map or not
        //if exist then print or else store into the map 
        if(m.find(second) != m.end() && m[second] == first)
        {
            cout<<"("<<first<<" "<<second<<")"<<" ";
        }
        else
        {
            //store it into the map
            m[first] = second;
        }
    }
    return 0;
}*/

