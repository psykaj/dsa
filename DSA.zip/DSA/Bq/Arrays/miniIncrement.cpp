
//gfg question :- Make array elements unique

#include <iostream>
#include <algorithm>
using namespace std;
//Tc = O(N log n) -> using sort stl function
//Sc = O(1) -> do not use any data structure

int miniIncrements(int arr[],int n)
{
    sort(arr,arr+n);
    int ans = 0;
    for(int i=1;i<n;i++)
    {
        if(arr[i-1] >= arr[i])
        {
            ans += (arr[i-1]-arr[i]+1);
            cout<<"ans : "<<ans<<endl;
            arr[i] = arr[i-1]+1;
            cout<<i <<"Arr[i] update : "<<arr[i]<<endl;
        }
    }
    return ans;
}

int main()
{
    int arr[] = {1,2,1,2};
    int n = sizeof(arr)/sizeof(arr[0]);
    int ans = miniIncrements(arr,n);
    cout<<"The minimum Increment required make all element unique is : "<<ans<<endl;
    return 0;
}
