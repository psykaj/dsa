//Two pointer
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(N)
//Sc = O(1) 
int dup(int arr[],int n)
{
    int i = 0;
    for(int j=i+1;j<n;j++)
    {
        if(arr[i] != arr[j])
        {
            i++;
            arr[i] = arr[j];
        }
    }
    
    return i+1; //because arry is traversed from 0 so return i+1;
}

int main()
{
    int arr[]={1,1,2,2,2,3,3};
    int n=sizeof(arr)/sizeof(arr[0]);
    int k = dup(arr,n);
    for(int i=0;i<k;i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}*/





//Using set
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(NlogN) + O(N)
//Sc = O(N) for taking set 
int dup(int arr[],int n)
{
    set<int> s;
    for(int i=0;i<n;i++)
    {
        s.insert(arr[i]);
    }
    
    int k = s.size();
    int j=0;
    //put all the element of set into array 
    for(auto x:s)
    {
        arr[j++] = x;
    }
    return k;
}

int main()
{
    int arr[]={1,1,2,2,2,3,3};
    int n=sizeof(arr)/sizeof(arr[0]);
    int k = dup(arr,n);
    for(int i=0;i<k;i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}*/


