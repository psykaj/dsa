#include <iostream>
#include <vector>
#include <climits>
using namespace std;
//Tc = O(N)3
//Sc = O(1)
int maxProductSubArray(vector<int>& nums)
{
    int ans = INT_MIN;
    for(int i=0;i<nums.size()-1;i++)
    {
        for(int j=i+1;j<nums.size();j++)
        {
            int mutliply = 1;
            for(int k=i;k<=j;k++)
            {
                mutliply *= nums[k];
                cout<<mutliply<<" ";
            }
            cout<<endl;
            ans = max(ans,mutliply);
        }
    }
    return ans;
}

int main()
{
    vector<int> nums = {1,2,-3,0,-4,-5};
    cout<<"The maximum product subarray: "<<maxProductSubArray(nums);
    return 0;
}


//Kadane's Algorithm
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int maxProductSubArray(vector<int>& nums)
{
    int prod1 = nums[0] , prod2 = nums[0] , result = nums[0];
    
    for(int i=1;i<nums.size();i++)
    {
        //In each traversal of i multiply with previous prod1 and prod2 
        //and then multiply you will get correct answer
        int temp = max({nums[i],prod1*nums[i],prod2*nums[i]});
        cout<<"temp : "<<temp<<endl;
        prod2 = min({nums[i],prod1*nums[i],prod2*nums[i]});
        cout<<"prod2 : "<<prod2<<endl;
        prod1 = temp;
        cout<<"prod1 : "<<prod1<<endl;
        
        result = max(result,prod1);
        cout<<"result : "<<result<<endl;
    }
    return result;
}
int main()
{
    vector<int> nums = {1,2,-3,0,-4,-5};
    cout<<"The maximum product subarray: "<<endl;
    maxProductSubArray(nums);
    return 0;
}*/

