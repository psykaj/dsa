//Brute force
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(NlogN) + O(N); sort and traverse
//Sc= O(1); using hashmap
void repeatingElement(int arr[],int n)
{
    sort(arr,arr+n);
    
    for(int i=0;i<n;i++)
    {
        if(arr[i] == arr[i+1])
        {
            cout<<arr[i]<<" ";
        }
    }
}

int main()
{
    int arr[]={1,1,2,3,4,4,5,2};
    int n=sizeof(arr)/sizeof(arr[0]);
    repeatingElement(arr,n);
    return 0;
}*/

//Optimise approch
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(N); for traverse
//Sc= O(N); using hashmap
void repeatingElement(int arr[],int n)
{
    map<int,int> m;
    for(int i=0;i<n;i++)
    {
        m[arr[i]]++;
    }
    
    cout<<"The Repeating Element in an array is : ";
    for(auto x:m)
    {
        if(x.second > 1)
        {
            cout<<x.first<<" ";
        }
    }
}

int main()
{
    int arr[]={1,1,2,3,4,4,5,2};
    int n=sizeof(arr)/sizeof(arr[0]);
    repeatingElement(arr,n);
    return 0;
}*/

//find Non-repeating Element in an array 
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(N); for traverse
//Sc= O(N); using hashmap
void repeatingElement(int arr[],int n)
{
    map<int,int> m;
    for(int i=0;i<n;i++)
    {
        m[arr[i]]++;
    }
    
    cout<<"The Repeating Element in an array is : ";
    for(auto x:m)
    {
        if(x.second == 1)
        {
            cout<<x.first<<" ";
        }
    }
}

int main()
{
    int arr[]={1,2,-1,1,3,1};
    int n=sizeof(arr)/sizeof(arr[0]);
    repeatingElement(arr,n);
    return 0;
}*/




