Tc = O(N*M);
Sc= O(1);
#include <iostream>
using namespace std;
bool isSubset(int arr1[],int n,int arr2[],int m)
{
    if(n>m)
    {
        return false;
    }
    for(int i=0;i<n;i++)
    {
        bool present = false;
        for(int j=0;j<m;j++)
        {
            if(arr1[i] == arr2[j])
            {
                present = true;
                break;
            }
        }
        if(present == false)
        {
        return false;
        }
    }
    return true;
}

int main()
{
    int arr1[]={1,3,4,5,2};
	int arr2[]={2,4,3,1,7,5,15};
	
	int n= sizeof(arr1)/sizeof(arr1[0]);
	int m= sizeof(arr2)/sizeof(arr2[0]);
	
	bool ans = isSubset(arr1,n,arr2,m);
	
	if(ans == true)
	{
	    cout<<"arr1 is a subset of arr2";
	}
	else
	{
	    cout<<"arr1 is not a subset of arr2";
	}
    return 0;
}

/*Tc = O(mlogm + nlogn);
Sc = O(1);
#include <iostream>
#include <algorithm>
using namespace std;
//element is reference of arr1[];
bool binarySearch(int element,int arr2[],int n)
{
    int s = 0;
    int e = n-1;
    
    while(s<=e)
    {
        int mid = s + (e - s)/2;
        if(arr2[mid] > element)
        {
            e = mid - 1;
        }
        else if(arr2[mid] < element)
        {
            s = mid + 1;
        }
        else
        {
            return true;
        }
    }
    
    return false;
}

bool isSubset(int arr1[],int m,int arr2[],int n)
{
    sort(arr2,arr2+n);
    
    for(int i=0;i<m;i++)
    {
        bool present = binarySearch(arr1[i],arr2,n);
        if(!present)
        {
            return false;
        }
    }
    return true;
}

int main()
{
    int arr1[]={1,3,4,5,2};
    int arr2[]={2,4,3,1,7,5,15};
    
    int m= sizeof(arr1)/sizeof(arr1[0]);
    int n= sizeof(arr2)/sizeof(arr2[0]);
    
    bool ans= isSubset(arr1,m,arr2,n);
    
    if(ans==true)
        cout<<"arr1[] is a subset of arr2[]";
    else cout<<"arr1[] is not a subset of arr2[]";

    return 0;
}*/


//Optimal Approch
/*#include <bits/stdc++.h>
using namespace std;
//Tc = O(N + M); for traversal
//Sc = O(N); taken hashmap
bool isSubset(int arr1[],int m,int arr2[],int n)
{
    if(m>n)
    {
        return false;
    }
    
    unordered_map<int,bool> mp;
    
    for(int i=0;i<n;i++)
    {
        mp[arr2[i]] = true;
    }
    
    for(int i=0;i<m;i++)
    {
        if(mp.count(arr1[i]) == 0)
        {
            return false;
        }
    }
    return true;
}

int main()
{
    int arr1[]={1,3,4,5,2};
    int arr2[]={2,4,3,1,7,5,15};
    
    int m= sizeof(arr1)/sizeof(arr1[0]);
    int n= sizeof(arr2)/sizeof(arr2[0]);
    
    bool ans= isSubset(arr1,m,arr2,n);
    
    if(ans)
    {
        cout<<"arr1[] is a subset of arr2[]";
    }
    else 
    {
        cout<<"arr1[] is not a subset of arr2[]";
    }
    
    return 0;
}*/


