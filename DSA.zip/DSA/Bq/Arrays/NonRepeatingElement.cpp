#include <bits/stdc++.h>
using namespace std;
/*Tc = O(N)2 + O(N)
Sc = O(1)
void nonRepeating(int arr[],int n)
{
    bool check;
    for(int i=0;i<n;i++)
    {
        check = false;
        for(int j=0;j<n;j++)
        {
            if(i != j && arr[i] == arr[j])
            {
                check = true;
                break;
            }
        }
        if(!check)
        {
        cout<<arr[i]<<" ";
        }
    }
}


2) Tc = NlogN + O(N)
Sc = O(1)
void nonRepeating(int arr[],int n)
{
    sort(arr,arr+n);
    if(arr[0] != arr[1])
    {
        cout<<arr[0]<<" ";
    }
    
    for(int i=1;i<n-1;i++)
    {
        if(arr[i] != arr[i-1] && arr[i] != arr[i+1])
        {
            cout<<arr[i]<<" ";
        }
    }
    
    if(arr[n-2] != arr[n-1])
    {
        cout<<arr[n-1]<<" ";
    }
}

3) Tc = O(N)
Sc = O(N)

void nonRepeating(vector<int>& arr)
{
    unordered_map<int,int> m;
    for(auto i:arr)
    {
        m[i]++;
    }
    
    for(auto i:m)
    {
        if(i.second == 1)
        {
            cout<<i.first<<" ";
        }
    }
}*/

int main()
{
    vector<int> arr = {1,2,-1,1,3,1};
    int n = sizeof(arr)/sizeof(arr[0]);
    nonRepeating(arr);

    return 0;
}
