#include <iostream>
#include <algorithm>
using namespace std;

// Uding temp variable
// void swapNumbers(int a,int b)
// {
//     int temp = a;
//     a = b;
//     b = temp;
//     cout<<a<<" "<<b<<endl;
// }

// using arthemetic operations (+,-)
// void swapNumbers(int a,int b)
// {
//     a = a+b;
//     b = a-b;
//     a = a-b;
//     cout<<a<<" "<<b<<endl;
// }

// using xor operators
// void swapNumbers(int a,int b)
// {
//     a = a^b;
//     b = a^b;
//     a = a^b;
//     cout<<a<<" "<<b<<endl;
// }

int main()
{
    int a=5;
    int b=6;
    // using swap method
    // swap(a,b);
    // cout<<a<<" "<<b<<endl;
    swapNumbers(a,b);
    return 0;
}