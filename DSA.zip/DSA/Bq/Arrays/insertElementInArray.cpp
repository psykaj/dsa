#include <bits/stdc++.h>
using namespace std;
/*void insertAtBegining(int arr[],int n,int value)
{
    for(int i=n-1;i>=0;i--)
    {
        arr[i+1] = arr[i];
    }
    arr[0] = value;
}*/

/*void insertAtEnd(int arr[],int n,int value)
{
    arr[n] = value;
}*/

/*void insertInMiddle(int arr[],int n,int value,int pos)
{
    for(int i=n;i>=pos;i--)
    {
        arr[i] = arr[i-1];
    }
    arr[pos - 1] = value;
}*/

int main()
{
    int arr[]={10,9,14,8,20,48,16,9};
    int n=sizeof(arr)/sizeof(arr[0]);
    int pos = 4;
    int value = 40;
    cout<<"Array before inserting the element : ";
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    //insertAtBegining(arr,n,value);
    //insertAtEnd(arr,n,value);
    insertInMiddle(arr,n,value,pos);
    cout<<"Array after inserting the element : ";
    for(int i=0;i<=n;i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}
