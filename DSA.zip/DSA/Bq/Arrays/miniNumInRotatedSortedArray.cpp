#include <iostream>
#include <climits>
using namespace std;

//Brute force approch
//Tc = O(N);
//Sc = O(1);
/*int minRotatedSortedArray(int arr[],int n)
{
    int mini = INT_MAX;
    
    for(int i=0;i<n;i++)
    {
        //approch 1 
        if(arr[i] < mini)
        {
            mini = arr[i];
        }
        
        //approch 2
        mini = min(arr[i],mini);
    }
    return mini;
}*/

int minRotatedSortedArray(int arr[],int n)
{
    int start = 0;
    int end = n-1;
    int mini = INT_MAX;
    
    while(start <= end)
    {
        //when array is sorted 
        if(arr[start] < arr[end])
        {
            mini = min(arr[start],mini);
            return mini;
        }
    
        int mid = start + (end - start)/2;
    
        //if left part of array is sorted
        if(arr[start] <= arr[mid])
        {
            mini = min(arr[start],mini);

            //Tricky part
            //we will check on right part wheather still any minimum value is there or not
            start = mid + 1;  
        }
        else //if left part is not sorted right half must be sorted 
        {
            mini = min(arr[mid],mini);

            //Tircky part
            //we will check on left part wheather still any minimum value is there or not 
            end = mid - 1; 
        }
    }
    return mini;
}

int main()
{
    int arr[]={4,5,1,2,3};
    int n = 5;
    cout<<"Minimum number in rotated sorted array : "<<minRotatedSortedArray(arr,n);
    return 0;
}
