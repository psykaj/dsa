#include<bits/stdc++.h>
using namespace std;
/*Tc = O(N)2 + O(N)
Sc = O(N)
void dup(int arr[],int n)
{
    int count = 0;
    int dup[n];
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(arr[i] == arr[j])
            {
                dup[count++] = arr[i];
            }
        }
    }
    
    for(int i=0;i<count;i++)
    {
        if(dup[i] != dup[i+1])
        {
            cout<<dup[i]<<" ";
        }
    }
}*/

/*
Tc = NlogN + O(N)
Sc = O(1)
void dup(int arr[],int n)
{
    sort(arr,arr+n);
    
    for(int i=0;i<n;i++)
    {
        if(arr[i] == arr[i+1])
        {
            cout<<arr[i]<<" ";
        }
    }
}*/

/*
Tc = O(N);
Sc = O(N);
void dup(vector<int>& arr,int n)
{
    unordered_map<int,int> m;
    for(auto i : arr)
    {
        m[i]++;
    }
    
    for(auto i:m)
    {
        if(i.second > 1)
        {
            cout<<i.first<<" ";
        }
    }
}*/

int main()
{
    vector<int> arr = {1,1,2,3,4,4,5,2};
    int n = sizeof(arr)/sizeof(arr[0]);
    dup(arr,n);

    return 0;
}
