/*//Tc = O(N);
//Sc = O(1);
#include <iostream>
#include <climits>
using namespace std;
void getElements(int arr[],int n)
{
    int small = INT_MAX , secondSmall = INT_MAX;
    int large = INT_MIN , secondLarge = INT_MIN;
    
    for(int i=0;i<n;i++)
    {
        small = min(arr[i],small); //get small
        large = max(arr[i],large); //get large
    }
    
    for(int i=0;i<n;i++)
    {
        if(arr[i]<secondSmall && arr[i] != small) //get secondSmall
        {
            secondSmall = arr[i];
        }
        
        if(arr[i]>secondLarge && arr[i] != large) //get secondLarge
        {
            secondLarge = arr[i];
        }
    }
    
    cout<<secondSmall<<endl;
    cout<<secondLarge<<endl;
}

int main()
{
    int arr[]={1,2,4,6,7,5};
    int n=sizeof(arr)/sizeof(arr[0]);
    getElements(arr,n);
    return 0;
}*/

//Single pass solution
/*#include <iostream>
#include <climits>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int getSecondSmall(int arr[],int n)
{
    int small = INT_MAX , secondSmall = INT_MAX;
    
    if(n<2)
    {
        return -1;
    }
    
    int i=0;
    for(i=0;i<n;i++)
    {
        if(arr[i] < small)
        {
            secondSmall = small;
            small = arr[i];
        }
        else if(arr[i] < secondSmall && arr[i] != small)
        {
            secondSmall = arr[i];
        }
    }
    return secondSmall;
}

int getSecondLarge(int arr[],int n)
{
    int large = INT_MIN , secondLarge = INT_MIN;
    
    if(n<2)
    {
        return -1;
    }
    
    int i=0;
    for(i=0;i<n;i++)
    {
        if(arr[i] > large)
        {
            secondLarge = large;
            large = arr[i];
        }
        else if(arr[i] > secondLarge && arr[i] != large)
        {
            secondLarge = arr[i];
        }
    }
    return secondLarge;
}

int main()
{
    int arr[]={1,2,4,6,7,5};
    int n=sizeof(arr)/sizeof(arr[0]);
    cout<<"The second smallest element in an array is : "<<getSecondSmall(arr,n)<<endl;
    cout<<"The second largest element in an array is : "<<getSecondLarge(arr,n)<<endl;
    return 0;
}*/

