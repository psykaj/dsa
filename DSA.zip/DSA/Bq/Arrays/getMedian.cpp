//Get median of an array 
#include <bits/stdc++.h>
using namespace std;
//Tc = O(N * logN)
//Sc = O(1)
void getMedian(int arr[],int n)
{
    sort(arr,arr+n);
    if(n % 2 == 0)
    {
        int index1 = (n/2)-1;
        int index2 = (n/2);
        cout<<(double)(arr[index1]+arr[index2])/2;
    }
    else
    {
        cout<<arr[(n/2)];
    }
}

int main()
{
    int arr[]={1, 2, 3, 4, 5,6,7,8};
    int n=sizeof(arr)/sizeof(arr[0]);
    getMedian(arr,n);
    return 0;
}
