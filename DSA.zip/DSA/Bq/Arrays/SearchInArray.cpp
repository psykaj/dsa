#include <iostream>
using namespace std;
/*Tc = O(N);
Sc = O(1);
int searchElement(int arr[],int n,int k,int ans)
{
    for(int i=0;i<n;i++)
    {
        if(arr[i] == k)
        {
            ans = i;
            break;
        }
    }
    return ans;
}*/

/*Tc = O(logn);
Sc = O(1);
int binarySearch(int arr[],int n,int k,int ans)
{
    int s = 0;
    int e = n-1;
    while(s<=e)
    {
        int mid = s + (e - s)/2;
        if(arr[mid] > k)
        {
            e = mid - 1;
        }
        else if(arr[mid] < k)
        {
            s = mid + 1;
        }
        else 
        {
            ans = mid;
            break;
        }
        
    }
    return ans;
}*/

int main()
{
    int n = 6;
	int arr[n] = {6, 7, 9, 5, 3, 11};
	int k = 11;
	int ans = -1;
	cout<<binarySearch(arr,n,k,ans);
    return 0;
}
