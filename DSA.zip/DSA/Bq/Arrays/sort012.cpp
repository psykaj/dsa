//optimize approch is dutch national flag algorithm
#include <iostream>
using namespace std;
//tc = O(N);
//sc = O(1);
void sort012(int arr[],int n)
{
    int zero = 0,one = 0,two = 0;
    for(int i=0;i<n;i++)
    {
        if(arr[i] == 0)
        {
            zero++;
        }
        else if(arr[i] == 1)
        {
            one++;
        }
        else
        {
            two++;
        }
    }
    
    int i=0;
    while(zero--) //(zero != 0) ; zero--; karna padega
    {
        arr[i] = 0;
        i++;
    }
    
    while(one--)
    {
        arr[i] = 1;
        i++;
    }
    
    while(two--)
    {
        arr[i] = 2;
        i++;
    }
}

//Approch 2 -> Dutch National flag Algorithm
//Tc = O(N);
//Sc = O(1);
/*void sort012(int arr[],int n)
{
    int start = 0;
    int mid = 0;
    int end = n-1;
    
    while(mid <= end)
    {
        switch(arr[mid])
        {
            case 0:
                swap(arr[start++],arr[mid++]);
                break;
            
            case 1:
                mid++;
                break;
            
            case 2:
                swap(arr[mid],arr[end--]);
                break;
        }
    }
}*/

void printArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int arr[] = {0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1};
    int size = 12;
    sort012(arr,size);
    printArray(arr,size);
    return 0;
}
