/*#include <iostream>
using namespace std;
// Ager Last K element want to bring first then this approch
//1)Brute force
//Tc = O(N)
//Sc = O(K)
void Rotatetoright(int arr[],int n,int k)
{
    if(n == 0)
    {
        return;
    }
    
    //if value of k is larger than n
    k = k % n;
    
    if(k > n)
    {
        return;
    }
    
    int temp[k]; //to store k element into temp array 
    
    //putting all k element into the temp array 
    for(int i=n-k;i<n;i++)
    {
        temp[i-n+k] = arr[i];
    }
    
    //shift all the element by k 
    for(int i=n-k;i>=0;i--)
    {
        arr[i+k] = arr[i];
    }
    
    //putting k element into starting of an array 
    for(int i=0;i<k;i++)
    {
        arr[i] = temp[i];
    }
}

int main()
{
    int n = 7;
    int arr[] = {1, 2, 3, 4, 5, 6, 7};
    int k = 2;
    Rotatetoright(arr, n, k);
    cout << "After Rotating the elements to left : ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    return 0;
}*/

/* Tc = O(N);
Sc = O(K);
#include <iostream>
using namespace std;
//If you want to bring k element into last of an array 
void Rotatetoright(int arr[],int n,int k)
{
    if(n == 0)
    {
        return;
    }
    
    //if value of k is larger than n
    k = k % n;
    
    if(k > n)
    {
        return;
    }
    
    int temp[k]; //to store k element into temp array 
    
    //putting all k element into the temp array 
    for(int i=0;i<k;i++)
    {
        temp[i] = arr[i];
    }
    
    //shift all the element by k 
    for(int i=0;i<n-k;i++)
    {
        arr[i] = arr[i+k];
    }
    
    //putting k element into starting of an array 
    for(int i=n-k;i<n;i++)
    {
        arr[i] = temp[i-n+k];
    }
}

int main()
{
    int n = 7;
    int arr[] = {1, 2, 3, 4, 5, 6, 7};
    int k = 2;
    Rotatetoright(arr, n, k);
    cout << "After Rotating the elements to left : ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    return 0;
}*/

//Approch 3
#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
//reverse algorithm
void reverse(int arr[],int start,int end)
{
    while(start<=end)
    {
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        start++;
        end--;
    }
}

//If you want to bring k element into last of an array 
void Rotatetoright(int arr[],int n,int k)
{
    reverse(arr,0,n-k-1); //from element 1 to 5
    reverse(arr,n-k,n-1); //element 6 and 7
    reverse(arr,0,n-1); //reverse all the elememt
}

int main()
{
    int n = 7;
    int arr[] = {1, 2, 3, 4, 5, 6, 7};
    int k = 2;
    Rotatetoright(arr, n, k);
    cout << "After Rotating the elements to left : ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    return 0;
}



