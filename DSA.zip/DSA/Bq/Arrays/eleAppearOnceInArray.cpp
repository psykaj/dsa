#include <iostream>
using namespace std;

//brute force approch
//Tc = O(N);
//Sc = O(1);
/*void singleEleInArray(int arr[],int n)
{
    int ans = 0;
    for(int i=0;i<n;i++)
    {
        ans = ans^arr[i];
        cout<<ans<<" ";
    }
    cout<<endl;
    cout<<"The single element in an array is : "<<ans<<endl;
}*/

//Another brute force approch
//Tc = O(N);
//Sc = O(1);
/*int singleEleInArray(int arr[],int n)
{
    if(n == 1)
    {
        return arr[0];
    }
    
    for(int i=0;i<n;i++)
    {
        if(arr[i] != arr[i-1] && arr[i] != arr[i+1])
        {
            return arr[i];
        }
    }
    return -1;
}*/

//optimal approch
//recursion
//Tc = O(logn);
//Sc = O(1);
void binarySearch(int arr[],int start,int end)
{
    //base case 
    if(start > end)
    {
        return;
    }
    
    if(start == end)
    {
        cout<<"The single element in an array is : "<<arr[start]<<endl; //or arr[end] 
        return;
    }
    
    //find the middle element
    int mid = (start + end) /2;
    
    //if mid is even 
    // If mid is even and element next to mid is
    // same as mid, then output element lies on
    // right side, else on left side
    if(mid % 2 == 0)
    {
        if(arr[mid] == arr[mid+1])
        {
            binarySearch(arr,mid+2,end);
        }
        else
        {
            binarySearch(arr,start,mid);
        }
    }
    else //if mid is odd
    {
        if(arr[mid] == arr[mid-1])
        {
            binarySearch(arr,mid+1,end);
        }
        else
        {
            binarySearch(arr,start,mid-1);
        }
    }
}

int main()
{
    int arr[] = {1, 1, 2, 2, 3, 3, 4, 50, 50, 65, 65};
    int n = 11;
    //singleEleInArray(arr,n);
    binarySearch(arr,0,n-1);
    return 0;
}
