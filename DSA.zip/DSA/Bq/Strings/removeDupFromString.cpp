#include <iostream>
#include <vector> 
using namespace std;
//Tc = O(N);
//Sc = O(1); since the string has only characters from ‘a’ to ‘z’, the maximum size of the array is 26.
//cause vector is taken for 'a'-'z' character which is 26 which is ultimately O(1);
string removeDuplicateLetters(string str)
{
    string ans = "";
    vector<bool> v(26,false);
    
    for(int i=0;i<str.length();i++)
    {
        //vector v k (str[i] - 'a') wale index pe true kar denge 
        if(v[str[i] - 'a'] == false) 
        {
            ans += str[i];
            v[str[i] - 'a'] = true;
        }
    }
    return ans;
}

int main()
{
    string str = "cbacdcbc";
    cout << "Original String: "<<str<<endl;
    cout<<"After removing duplicates : "<<removeDuplicateLetters(str) << endl;

    return 0;
}
