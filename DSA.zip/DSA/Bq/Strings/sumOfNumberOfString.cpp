#include <iostream>
using namespace std;
//Tc = O(N) for One traversal
//Sc = O(N) for string size
class Solution {
public:
    
    int sumOfIntegers(string st,int l)
    {
        string tempSum = "";
        int sum = 0;
    
        for(int i=0;i<l;i++)
        {
            if(st[i] >= '0' && st[i] <= '9')
            {
                tempSum = tempSum +  st[i];
            }
            else
            {
                //The atoi() function converts a character string to an integer value
                //We can also use (stoi) instead of (atoi)
                sum = sum + atoi(tempSum.c_str());
                //The c_str() method converts a string to an array of characters with a null character at the end.
                //The function takes in no parameters and returns a pointer to this character array 
                //(also called a c-string).
                tempSum = "";
            }
        }
        int ans = sum + atoi(tempSum.c_str());
        return ans;
    }
};

int main()
{
    string st = "1a30z67"  ;
    int l = st.length()  ;
    Solution obj ;
    cout << "Sum: "  ;
    cout << obj.sumOfIntegers(st, l)  ;
    return 0;
}
