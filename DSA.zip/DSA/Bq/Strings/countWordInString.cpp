#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int main()
{
    string str = "pankaj anil yadav";
    int n = str.length();
    int spaces=0;
    
    for(int i=0;i<n;i++)
    {
        if(str[i] == ' ')
        {
            spaces++;
        }
    }
    
    cout<<"The number of words in the string is : "<<spaces + 1 <<endl;
  
    return 0;
}