/*#include <iostream>
#include <vector> 
using namespace std;
//Tc = O(N);
//Sc = O(N) taken vector
void reverseWord(string s)
{
    vector<string> temp;
    int n = s.length();
    string str = "";
    for(int i=0;i<n;i++)
    {
        if(s[i] == ' ')
        {
            temp.push_back(str);
            str = "";
        }
        else
        {
            str += s[i]; 
        }
    }
    
    temp.push_back(str);
    
    for(int i=temp.size()-1;i>=0;i--)
    {
        cout<<temp[i]<<" ";
    }
}

int main()
{
    string s="TUF is great for interview preparation";
    cout<<"Before reversing words: "<<endl;
    cout<<s<<endl;
    cout<<"After reversing words: "<<endl;
    reverseWord(s);
    return 0;
}*/

//Optimise approch
/*#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
string result(string st)
{
    int s = 0;
    int e = st.length()-1;
    
    string temp = "";
    string ans = "";
    
    while(s <= e)
    {
        if(st[s] == ' ')
        {
            if(ans != "")
            {
                ans = temp + " " + ans;
            }
            else
            {
                ans = temp;
            }
            temp = "";
        }
        else
        {
            temp += st[s];
        }
        s++;
    }
    
    if(temp != "")
    {
        if(ans != "")
        {
            ans = temp + " " + ans;
        }
    }
    
    return ans;
    
}

int main()
{
    string st="TUF is great for interview preparation";
    cout<<"Before reversing words: "<<endl;
    cout<<st<<endl;
    cout<<"After reversing words: "<<endl;
    cout<<result(st);
    return 0;
}*/

