#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(N);  we have taken extra string to store ans 
int main()
{
    string str = "Pankaj12% $*&Anil $^$#Yadav";
    string v;
    for(int i=0;str[i];i++)
    {
        int ascii = (int) str[i]; //it will convert all words in int(ascii) value
        
        cout<<"Ascii value of "<< i <<" is : "<<ascii<<endl; //this is for understanding
        
        if((ascii >= 65 && ascii <= 90) || (ascii >= 97 && ascii <= 122))
        {
            v.push_back(str[i]);
        }
    }
    cout<<endl;
    cout<<"The String after the removal of everything except letters : "<<v;
    return 0;
}