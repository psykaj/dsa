#include <iostream>
#include <algorithm>
//Tc = O(nLogn)
//Sc = O(1)
using namespace std;
void Printfrequency(string str)
{
   sort(str.begin(),str.end());
   cout<<str<<endl;
   char ch = str[0];
   int count = 1;
   for(int i=1;i<str.length();i++)
   {
       if(str[i] == ch)
       {
           count++;
       }
       else
       {
           cout<<ch<<count<<" ";
           ch = str[i];
           count = 1;
       }
   }
   cout<<ch<<count<<" "; //for printing the last character 
}

int main()
{
  string str = "PankajAnilYadav";
  Printfrequency(str);
  return 0;
}