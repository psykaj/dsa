#include <iostream>
#include <algorithm>
using namespace std;
//brute force approch
//Tc = O(nlogn) -> used sorting algorithm
//Sc = O(1) -> constant space 
/*bool isAnagram(string str1,string str2)
{
    int n = str1.length();
    int m = str2.length();
    
    if(n != m)
    {
        return false;
    }
    
    sort(str1.begin(),str1.end());
    sort(str2.begin(),str2.end());
    
    for(int i=0;i<n;i++)
    {
        if(str1[i] != str2[i])
        {
            return false;
        }
    }
    return true;
}*/


//optimize approch
//Tc = O(N) -> traverse through the string n
//Sc = O(1) -> constant space 
/*bool isAnagram(string str1,string str2)
{
    int n = str1.length();
    int m = str2.length();
    
    if(n != m)
    {
        return false;
    }
    
    int freq[26] = {0};
    
    for(int i=0;i<n;i++)
    {
        freq[str1[i] - 'A']++; //adding to the frequency array 
    }
    
    for(int i=0;i<m;i++)
    {
        freq[str1[i] - 'A']--; //adding to the frequency array 
    }
    
    for(int i=0;i<26;i++)
    {
        if(freq[i] != 0)
        {
            return false;
        }
    }
    return true;
}*/

int main()
{
    string str1 = "INTEGER";
    string str2 = "TEGERNI";
    
    if(isAnagram(str1,str2))
    {
        cout<<"str1 and str2 is anagram of each other"<<endl;
    }
    else
    {
        cout<<"str1 and str2 is not an anagram of each other"<<endl;
    }

    return 0;
}
