#include <iostream>
using namespace std;
//Tc = O(1);
//Sc = O(1);
int main()
{
    char c = 'P';
    cout<<(int)c; //int(c)
    return 0;
}
