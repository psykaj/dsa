#include <iostream>
#include <string.h>
using namespace std;
// Function to remove vowels from a string
//Tc = O(N);
//Sc = O(1);
string RemoveVowels(string str)
{
  for (int i = 0; i < str.length(); i++)
  {
    if(str[i] == ' ')
    {
        str = str.substr(0,i) + str.substr(i+1);
        i--;
    }
  }
  return str;
}
int main()
{
  string str = "take u forward";
  cout <<"String after removing the vowels \n" <<RemoveVowels(str) << endl;
  return 0;
}


/*#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
string removeSpaces(char str[]) {
  int count = 0; // spaces seen so far

  for (int i = 0; str[i]; i++)
  {
  //In this case "for(int i = 0; str[i]; i++)", your loop keeps its execution until one of its elements are a 
  //null element. Always when you see this expression, it is always the same meaning that is checking out 
  //whether element is or not null, in order to stop the loop.
    if (str[i] != ' ') 
    { 
      // if whitespace is present
      str[count] = str[i]; // remove whitespace
      cout<<"string index : "<<count<<"->"<<str[i]<<endl;
      count++; // increment the count
      cout<<"count : "<<count<<endl;
    }
  }

  str[count] = '\0'; //count will end 

  return str;
}

int main() 
{
  char str[] = "Take you forward";
  string ans = removeSpaces(str);
  cout<<"Sentences after removal of spaces is : "<<ans<<endl;
  return 0;
}*/