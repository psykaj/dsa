#include <iostream>
using namespace std;
//Tc = O(n) + O(n) = O(n) 
// 1) travesal , 2) using substr function
//Sc = O(n) -> using string to print ans 
void MaxLengthWords(string str,string& maxWord)
{
    int n = str.length();
    int i = 0 , j = 0;
    int max_length = 0;
    int max_start = 0;
    
    while(j <= n)
    {
        if(j < n && str[j] != ' ')
        {
            j++;
        }
        else
        {
            cout<<i<<" "<<j<<endl;
            int curr_length = j - i;
            cout<<curr_length<<endl;
            if(curr_length > max_length)
            {
                max_length = curr_length;
                max_start = i;
                cout<<max_length<<" "<<max_start<<endl;
            }
            j++;
            i = j;
            cout<<i<<" "<<j<<endl;
        }
    }
    cout<<max_start<<" "<<max_length<<endl;
    maxWord = str.substr(max_start,max_length);
}

int main()
{
    string str = "Google Docs";
    string maxWord;
    MaxLengthWords(str, maxWord);
    cout << "Largest Word is: " << maxWord << endl;
    return 0;
}
