#include <iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* left;
    Node* right;
    
    Node(int d)
    {
        data = d;
        left = NULL;
        right = NULL;
    }
};

Node* buildTree() {
    cout<<"Enter the value of data : "<<endl;
    int data;
    cin>>data;
    
    if(data == -1)
    {
        return NULL;
    }
    
    Node* newNode = new Node(data);
    
    cout<<"Enter the data for Left Child : "<<endl;
    
    newNode -> left = buildTree();
    
    cout<<"Enter the data for Right Child : "<<endl;
    
    newNode -> right = buildTree();
    
    return newNode;
    
} 


//Traveral of tree in preOrder
//Tc = O(N);
//Sc = O(N); 
void preOrder(Node* &root) {
    //base case
    if(root == NULL)
    {
        return;
    }
    
    //Node (N)
    cout<<root->data<<endl;
    
    //left (L)
    preOrder(root->left);
    
    //right (R)
    preOrder(root->right);
}

//InOrder LNR
//Tc = O(n);
//Sc = O(n);
void inOrder(Node* &root) {
    //base case
    if(root == NULL)
    {
        return;
    }
    
    //left (L)
    inOrder(root->left);
    
    //Node (N)
    cout<<root->data<<endl;
    
    //right (R)
    inOrder(root->right);
}

//postOrder LRN
//Tc = O(n);
//Sc = O(n);
void postOrder(Node* &root) {
    //base case
    if(root == NULL)
    {
        return;
    }
    
    //left (L)
    postOrder(root->left);
    
    //right (R)
    preOrder(root->right);
    
    //Node (N)
    cout<<root->data<<endl;
}

//Level Order Traversal 
//Tc = O(N);
//Sc = O(N);
void levelOrderTraversal(Node* &root) {
    queue<Node*> q;
    q.push(root);
    //first change (Only one element in root level)
    q.push(NULL);
    
    while(!q.empty())
    {
        Node* front = q.front();
        q.pop();
        
        if(front == NULL)
        {
            cout<<endl;
            
            //Catch lines 
            if(!q.empty())
            {
                q.push(NULL);
            }
        }
        else
        {
            cout<<front->data<<" ";
        
        
            if(front->left != NULL)
            {
                q.push(front->left);
            }
        
            if(front->right != NULL)
            {
                q.push(front->right);
            }
        } 
    }
}

//Height of tree 
//Tc = O(N);
//Sc = O(N);
int height(Node* &root) {
    if(root == NULL)
    {
        return 0;
    }
    
    if(root->left == NULL && root->right == NULL)
    {
        return 0;
    }
    
    int leftAns = height(root->left);
    
    int rightAns = height(root->right);

    int ans = 1+max(leftAns,rightAns);
    
    return ans;
}


int main()
{
    Node* root = NULL;
    
    root = buildTree();

    preOrder(root);

    inOrder(root);

    postOrder(root);

    height(root);

    return 0;
}
