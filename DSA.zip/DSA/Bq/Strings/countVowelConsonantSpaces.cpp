#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int main()
{
    string str = "Pankaj Anil Yadav";
    int n = str.length();
    int vowel = 0;
    int consonant = 0;
    int whiteSpaces = 0;
    
    //towlower -> make capital letters to small letters 
    for(int i=0;i<n;i++)
    {
        str[i] = towlower(str[i]);
    }
    
    
    for(int i=0;i<n;i++)
    {
        if(str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u')
        {
            vowel++;
        }
        else if(str[i] == ' ')
        {
            whiteSpaces++;
        }
        else if(str[i] >= 'a' && str[i] <= 'z')
        {
            consonant++;
        }
    }
    
    cout<<"Vowel : "<<vowel<<endl;
    cout<<"Consonant : "<<consonant<<endl;
    cout<<"White Spaces : "<<whiteSpaces<<endl;
    

    return 0;
}
