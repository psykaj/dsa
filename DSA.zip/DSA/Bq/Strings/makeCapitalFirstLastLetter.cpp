//The ASCII codes for a-z are 97-122.
//The ASCII codes for A-Z are 65-90.

//To get A from a, you need to subtract 32.
//To get a from A, you need to add 32.

// (1)  (int) str[i] gives the ASCII value of the ith string character 
//      (Convert string to int)
// (2)  ((int) str[i] – 32) gives the ASCII value of the Capitalized ith string character 
//      (gives the int value of i character)
// (3)  (char)((int) str[i] – 32) converts the ASCII value to its corresponding character
//      (convert the string i ka int value uska character)

#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
/*void Capitalize(string str,int size)
{
    for(int i=0;i<size;i++)
    {
        if(i == 0 || i == (size - 1) && (int) str[i] >= 97) //97 means all lettes are starts from small
        //Converting first and last index character to uppercase
        {
            str[i] = ((char)(int) str[i] - 32); 
        }
        else if(str[i] == ' ')
        {
            //Converting the last index before space
            if(((int) str[i-1] - 32) >= 65) //65 means all lettes are starts from capital 
            {
                str[i-1] = ((char)((int) str[i-1] - 32));
            }
            
            //Converting the first index after space
            if(((int) str[i+1] - 32)>= 65)
            {
                str[i+1] = ((char)((int) str[i+1] - 32));
            }
        }
    }
    
    cout<<"Printing the string : "<<endl;
    cout<<str;
}

int main()
{
    string str = "take u forward is awesome";
    int size = str.length();

    Capitalize(str, size);
    return 0;
}*/

//Optimal approch  
//we can also do with towupper function
//towupper(): converts wide characters into uppercase
//Tc = O(N);
//Sc = O(1);
/*void Capitalize(string str,int size)
{
    for(int i=0;i<size;i++)
    {
        if(i == 0 || i == (size-1))
        {
            str[i] = towupper(str[i]);
        } 
        else if(str[i] == ' ')
        {
            str[i-1] = towupper(str[i-1]);
            str[i+1] = towupper(str[i+1]);
        }
    }
    
    cout<<str;
}

int main()
{
    string str = "take u forward is awesome";
    int size = str.length();

    Capitalize(str, size);
    return 0;
}*/



