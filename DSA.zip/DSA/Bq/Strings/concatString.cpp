#include <iostream>
#include <string>
using namespace std;
//Tc = O(1);
//Sc = O(1);
int main()
{
    //string str1 = "Hello";
    //string str2 = "World";
    
    //str1.append(str2);
    //str1 = str1 + " " + str2;
    //cout<<str1<<endl;
    
    /*char str1[100] ={'H','e','l','l','o'};
    char str2[100]= {'W','o','r','l','d'};
    strcat(str1,str2); //it will work on char array*/
    return 0;
}
