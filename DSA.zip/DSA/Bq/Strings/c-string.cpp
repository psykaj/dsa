#include <iostream>
#include <string>
using namespace std;
int main()
{
    //message
    string my_string = "Pankaj Yadav";
    
    //convert to c-string using c_str()
    string my_cstring = my_string.c_str();
    //The c_str() method converts a string to an array of characters with a null character at the end. 
    //The function takes in no parameters and returns a pointer to this character array 
    //(also called a c-string).

    //print my_cstring one-by-one
    for(int i =0; i<my_cstring.length();i++)
    {
        cout<<"character is : "<<my_string[i]<<"\n";
    }
    //print my_cstring
    cout<<"my cstring is " <<my_cstring<<"\n";

    return 0;
}