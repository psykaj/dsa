/*#include <iostream>
using namespace std;
//Tc = O(N^2) -> outer loop for traverse left pointer
//-> inner loop for Updating freq array , Updating currMaxiWord , traverse right pointer
//Sc = O(N)
class Solution {
public:
    void HighestRepeatedLetters(string str)
    {
        int n = str.length();
        int maxiWord = 0;
        int currMaxiWord = 0;
        string res = "";
        
        for(int left=0;left<n;)
        {
            //traverse right 
            int right = left + 1;
            while(str[right] != ' ' && right < n)
            {
                right++;
            }
            
            int freq[26] = {0};
            currMaxiWord = 0;
            //Updating freq array
            for(int i=left;i<right;i++)
            {
                freq[str[i] - 'a']++;
            }
            
            //Updating currMaxiWord
            for(int i=0;i<26;i++)
            {
                if(freq[i] > 1)
                {
                    currMaxiWord++;
                }
            }
            
            //Updating maxiWord
            if(currMaxiWord > maxiWord)
            {
                maxiWord = currMaxiWord;
                res = "";
                //left se right tak jo bhi word hai vo res mai store ho jayega
                for(int i=left;i<right;i++)
                {
                    res += str[i];
                }
            }
            
            //left will start from another word in string
            left = right + 1;
        }
        
        if(res.empty())
        {
            cout<<"-1";
        }
        else
        {
            cout << "Word with highest number of repeated letters : " ;
            cout << res << "\n"  ;
        }
    }
};

int main()
{
    string str = "abcdefg google microsoft"  ;
    Solution obj ;
    obj.HighestRepeatedLetters(str)  ;
    return 0;
}*/
