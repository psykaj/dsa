/*#include <iostream>
#include<string>
using namespace std;
//Tc = O(N^2)
//Sc = O(1);
int foundPattern(string text, string pattern) 
{
  int N = text.length();
  int M = pattern.length();

  for(int i=0;i<N;i++)
  {
    int temp = i; //outer loop ka index ko temp mai store karke check karo inner loop mai 
    int j = 0;
    
    for(j=0;j<M;j++)
    {
        if(text[temp] != pattern[j]) //ager char same name hai text aur pattern ka tho break
        {
            break;
        }
        else //ager hai tho temp ++ kardo
        {
            temp++;
        }
    }
    
    if(j == M) //check kar last mai ki j == M ho gaya h kya 
    {
        return i;
    }
  }
  return -1;
}

int main() {
  string text = "takeuforward";
  string pattern = "forward";
  int foundIdx = foundPattern(text, pattern);
  cout << "The substring starts from the index: "<<foundIdx << endl;
  return 0;
}*/

//Optimise approch
/*#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1);
int main() 
{
  string text = "takeuforward";
  string pattern = "forward";
  auto ans = text.find(pattern);
  cout <<"The substring starts from the index: " <<ans<<endl;
  return 0;
}*/
