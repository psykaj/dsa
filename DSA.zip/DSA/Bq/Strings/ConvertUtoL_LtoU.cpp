#include <iostream>
#include <cwctype> //header file for towlower & towupper
using namespace std;
//Tc = O(N);
//Sc = O(1);
/*void solve(string str,int n)
{
    for(int i=0;i<n;i++)
    {
        int ascii = (int) str[i]; //convert char into int 
        if(ascii >= 65 && ascii <= 90)
        {
            str[i] = ((char) (ascii + 32)); //if upper case hai (tho small kardo)
        }
        
        if(ascii >= 97 && ascii <= 122)
        {
            str[i] = ((char) (ascii - 32)); //if lower case hai (tho captial kardo)
        }
    }
    
    cout<<"After Converting : "<<str<<endl;
}*/


void solve(string str,int n)
{
    for(int i=0;i<n;i++)
    {
        int ascii = (int) str[i]; //convert char into int 
        if(str[i] >= 65 && str[i] <= 90)
        {
            str[i] = towlower(str[i]); //if upper case hai (tho small kardo)
        }
        
        if(ascii >= 97 && ascii <= 122)
        {
            str[i] = towupper(str[i]); //if lower case hai (tho captial kardo)
        }
    }
    
    cout<<"After Converting : "<<str<<endl;
}

int main()
{
    string str = "take u forward IS Awesome";
    int n = str.length();
    cout<<"Before Converting : "<<str<<endl;
    solve(str, n);
    return 0;
}
