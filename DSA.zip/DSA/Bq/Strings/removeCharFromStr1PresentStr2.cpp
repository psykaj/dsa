/*#include <iostream>
using namespace std;
//Tc = O(N*M) cause two string are there 
//Sc = O(N) for ans string
string solve(string str1,string str2)
{
    string ans = "";
    for(int i=0;i<str1.length();i++)
    {
        int flag = 0;
        for(int j=0;j<str2.length();j++)
        {
            if(str2[j] == str1[i])
            {
                flag = 1;
            }
        }
        if(flag != 1)
        {
            ans.push_back(str1[i]);
        }
    }
    return ans;
}

int main()
{
    string str1 = "abcdef";
    string str2 = "cefz";
    cout << "Final string : "<<solve(str1, str2);
    return 0;
}*/

//Optimize solution
/*#include<bits/stdc++.h>
using namespace std;
//Tc = O(N) for traversing
//Sc = O(N) taken hashmap
string solve(string str1,string str2)
{
    string ans = "";
    unordered_map<char,int> m;
    for(int i=0;i<str2.length();i++)
    {
        m[str2[i]]++;
    }
    
    for(int i=0;i<str1.length();i++)
    {
        if(m[str1[i]] != 1)
        {
            ans += str1[i];
        }
    }
    return ans;
}

int main()
{
    string str1 = "abcdef";
    string str2 = "cefz";
    cout << "Final string : "<<solve(str1, str2);
    return 0;
}*/

