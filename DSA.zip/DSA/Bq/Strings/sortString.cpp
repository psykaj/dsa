/*#include <iostream>
using namespace std;
//Bubble Sort Algorithm
//Tc = O(N^2);
//Sc = O(1);
string solve(string str,int n)
{
    for(int i=0;i<n-1;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            cout<<i<<" "<<j<<endl;
            cout<<str[j]<<" "<<str[j+1]<<endl;
            if(str[j] > str[j+1])
            {
                char temp = str[j];
                str[j] = str[j+1];
                str[j+1] = temp;
            }
        }
    }
    return str;
}

int main()
{
    string str = "zxcbg";
    int n = str.length();
    
    cout << "Given string: " << "\n";
    cout << str << "\n";

    cout << "After sorting: " << "\n";
    cout << solve(str, n) << "\n";
    return 0;
}*/

//Optimise approch
/*#include <iostream>
#include <algorithm>
//Tc = O(n log n) for sorting;
//Sc = O(1);
using namespace std;
string solve(string str,int n)
{
    sort(str.begin(),str.end());
    return str;
}

int main()
{
    string str = "zxcbg";
    int n = str.length();
    
    cout << "Given string: " << "\n";
    cout << str << "\n";

    cout << "After sorting: " << "\n";
    cout << solve(str, n) << "\n";
    return 0;
}*/