#include <iostream>
#include <string.h>
using namespace std;
// Function to remove vowels from a string
//Tc = O(N);
//Sc = O(1);
string RemoveVowels(string str)
{
  for (int i = 0; i < str.length(); i++)
  {
    if (str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U')
    {
      str = str.substr(0, i) + str.substr(i + 1); //(i+1) <- 1 se pura string print ho jayega
      //substr(0,i) = 0 se element lega per i th element nhi lega (uske phale tak lega bas)
      cout<<str<<endl;
      cout<<"before decrement i : "<<i<<endl;
      i--; //vowel element will remove from these 
      cout<<"after decrement i : "<<i<<endl;
    }
  }
  return str;
}
int main()
{
  string str = "take u forward";
  cout <<"String after removing the vowels \n" <<RemoveVowels(str) << endl;
  return 0;
}