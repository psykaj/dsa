#include <iostream>
using namespace std;
//Tc = O(N);
//Sc = O(1); since the string has only characters from ‘a’ to ‘z’, the maximum size of the array is 26.
int main()
{
    string str = "sinstriiintng";
    int arr[26] = {0};
    //arr k under sab char k count store ho jayenge iss for loop se
    for(int i=0;i<str.length();i++)
    {
        arr[str[i] - 'a']++;
    }
    
    cout<<"The duplicate character in strings are : "<<endl;
    //yeh for loop arr k liye hai 
    //isse arr mai jitne bhi char h vo print ho jayenge 
    for(int i=0;i<26;i++)
    {
        if(arr[i] > 1)
        {
            cout<<char(i + 'a')<<" -> "<<arr[i]<<endl;
        }
    }
    return 0;
}
