#include <iostream>
#include <algorithm>
using namespace std;
//optimize approch
//TC = O(n*max(arr[i])) -> and also used sort function
//Sc = O(max(arr[i])) -> used ans variable for extra space
string longCommonPrefixInArray(string str[],int n)
{
    sort(str,str+n);
    string str1 = str[0];
    string str2 = str[n-1];
    string ans = "";
    for(int i=0;i<str[0].size();i++) //we will traverse loop in first word in the string 
    {
        if(str1[i] == str2[i])
        {
            ans.push_back(str1[i]);
        }
        else
        {
            break;
        }
    }
    
    if(ans == "")
    {
        return "-1";
    }
    return ans;
}

int main()
{
    string str = {"geeksforgeeks","geeks","geek","geezer"};
    int n = sizeof(str)/sizeof(str[0]);
    cout<<"The longest common prefix in the given string is : "<<longCommonPrefixInArray(str,n);
    return 0;
}
