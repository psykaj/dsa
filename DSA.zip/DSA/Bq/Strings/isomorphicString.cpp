#include <bits/stdc++.h>
using namespace std;
#define maxChar 256     //or take 26 for alphabetical letters 
//brute force approch
//Tc = O(N) -> traverse the string of size n 
//Sc = O(1)
/*bool isIsomorphic(string str1,string str2)
{
    int n = str1.length();
    int m = str2.length();
    
    if(n != m)
    {
        return false;
    }
    
    int count[maxChar] = {0};
    int dCount[maxChar] = {0};
    
    for(int i=0;i<n;i++)
    {
        count[str1[i] - 'a']++;
        dCount[str2[i] - 'a']++;
    }
    
    for(int i=0;i<n;i++)
    {
        if(count[str1[i] - 'a'] != dCount[str2[i] - 'a'])
        {
            return false;
        }
    }
    return true;
}*/

//optimal approch (use hashing/map/unordered_map)
//Tc = O(N);
//Sc = O(1);
/*bool isIsomorphic(string str1,string str2)
{
    int n = str1.length();
    int m = str2.length();
    
    if(n != m)
    {
        return false;
    }
    
    unordered_map<char,char> mp1,mp2;
    
    for(int i=0;i<n;i++)
    {
        if(mp1.find(str1[i]) == mp1.end() && mp2.find(str2[i]) == mp2.end())
        {
            mp1[str1[i]] = str2[i];
            mp2[str2[i]] = str1[i];
        }
        else
        {
            if(mp1[str1[i]] != str2[i] || mp2[str2[i]] != str1[i])
            {
                return false;
            }
        }
    }
    return true;
}*/

int main()
{
    string str1 = "aab";
    string str2 = "xxy";
    
    if(isIsomorphic(str1,str2))
    {
        cout<<"The str1 and str2 is isomorphic in nature"<<endl;
    }
    else
    {
        cout<<"The str1 and str2 is not isomorphic in nature"<<endl;
    }

    return 0;
}
