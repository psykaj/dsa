// C++ program to count common subsequence in two strings
#include <bits/stdc++.h>
using namespace std;
//Tc = O(n1*n2)
//Sc = O(n1*n2)
// return the number of common subsequence in
// two strings
int CommomSubsequencesCount(string s, string t)
{
	int n1 = s.length();
	int n2 = t.length();
	int dp[n1+1][n2+1];

	for (int i = 0; i <= n1; i++) {
		for (int j = 0; j <= n2; j++) {
			dp[i][j] = 0;
		}
	}
	
	for (int i = 0; i <= n1; i++) {
		for (int j = 0; j <= n2; j++) {
			cout<<dp[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
	cout<<"dp is end here"<<endl;
	cout<<endl;

	// for each character of S
	for (int i = 1; i <= n1; i++) 
	{
		// for each character in T
		for (int j = 1; j <= n2; j++) 
		{
			// if character are same in both
			// the string
			//for Matching character
			if (s[i - 1] == t[j - 1])
			{
			    dp[i][j] = 1 + dp[i][j - 1] + dp[i - 1][j];
				cout<<"if condition : "<<dp[i][j]<<" ";
			}
			else //for Non-matching character
			{
			    dp[i][j] = dp[i][j - 1] + dp[i - 1][j] - dp[i - 1][j - 1];
				cout<<"else condition : "<<dp[i][j]<<" ";
			}
			cout<<endl;
		}
		cout<<endl;
	}

	return dp[n1][n2];
}

// Driver Program
int main()
{
	string s = "ajblqcpdz";
	string t = "aefcnbtdi";

	cout << CommomSubsequencesCount(s, t) << endl;
	return 0;
}
