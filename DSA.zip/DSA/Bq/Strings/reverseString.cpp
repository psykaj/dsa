/*Approch 1
#include <iostream>
#include <stack>
using namespace std;

int main()
{
    string str = "Pankaj";
    stack<char> st;
    int n = str.size();
    for(int i=0;i<n;i++)
    {
        st.push(str[i]);
    }
    
    int j = 0;
    while(!st.empty())
    {
        char ele = st.top();
        st.pop();
        str[j] = ele;
        j++;
    }
    
    cout<<str<<endl;

    return 0;
}*/


//approch 2
/*#include <iostream>
using namespace std;

void printRev(string &str)
{
    int len = str.length();
    int n = len - 1;
    int i = 0;
    
    while(i <= n)
    {
        swap(str[i],str[n]);
        i++;
        n--;
    }
}

int main()
{
    string str = "Pankaj";
    printRev(str);
    cout<<str<<endl;
    return 0;
}*/




//approch 3
/*#include <iostream>
#include <algorithm>
using namespace std;
int main()
{
    string str = "Pankaj";
    reverse(str.begin(),str.end());
    cout<<str<<endl;
    return 0;
}*/

//approch 4
/*#include <iostream>
using namespace std;
int main()
{
    string str = "Pankaj";
    int n = str.length();
    for(int i=n-1;i>=0;i--)
    {
        cout<<str[i]<<" ";
    }
    cout<<endl;
    return 0;
}*/


//approch 
//recursion using two pointer approch
/*void printRev(string &str,int start,int end)
{
    if(start >= end)
    {
        return;
    }
    
    swap(str[start],str[end]);
    start++;
    end--;
}

int main()
{
    string str = "PankajAnilYadav";
    int n = str.length();
    printRev(str,0,n-1);
    cout<<str<<endl;
    return 0;
}*/

//approch 
//recursion using one pointer
/*void printRev(string &str,int start)
{
    if(start >= str.length()-start-1)
    {
        return;
    }
    
    swap(str[start],str[str.length()-start-1]);
    //start++;
    printRev(str,start+1);
}


int main()
{
    string str = "PankajAnilYadav";
    int n = str.length();
    printRev(str,0);
    cout<<str<<endl;
    return 0;
}*/

