#include <iostream>
#include <queue>
using namespace std;
//brute/Naive approch
//Tc = O(n*m) -> n and m are the length of the strings
//Sc = O(N) -> taken 2 queues 
bool rotatedString(string str1,string str2)
{
    int n = str1.size();
    int m = str2.size();
    
    if(n != m)
    {
        return false;
    }
    
    queue<char> q1;
    for(int i=0;i<n;i++)
    {
        q1.push(str1[i]);
    }
    
    cout<<"Pushing characters of str1 in q1 : ";
    while(!q1.empty())
    {
        cout<<q1.front();
        q1.pop();
    }
    cout<<endl;
    
    queue<char> q2;
    for(int i=0;i<m;i++)
    {
        q2.push(str2[i]);
    }
    
    
    cout<<"Pushing characters of str2 in q2 : ";
    while(!q2.empty())
    {
        cout<<q2.front();
        q2.pop();
    }
    cout<<endl;
    
    int k = str2.size();
    cout<<"Size of str2 is : "<<k<<endl;
    
    while(k--)
    {
        char ch = q2.front();
        q2.pop();
        //it will check q2 with q1 is equal or not
        //keep popping element from q2 check it and again adding into q2
        //if same then return true else false 
        q2.push(ch);
        if(q1 == q2)
        {
            return true;
        }
    }
    return false;
}

//optimal approch 
//Tc = O(N) -> traverse the string
//Sc = O(N) -> taken temp variable
/*bool rotatedString(string str1,string str2)
{
    int n = str1.size();
    int m = str2.size();
    
    if(n != m)
    {
        return false;
    }
    
    string temp = str1 + str1;
    
    if(temp.find(str2) != string::npos) //if found str2 in temp
    {
        return true;
    }
    return false;
}*/

int main()
{
    string str1 = "geeksforgeeks";
    string str2 = "forgeeksgeeks";
    
    if(rotatedString(str1,str2))
    {
        cout<<"str1 ans str2 is a rotation of each other"<<endl;
    }
    else
    {
        cout<<"str1 ans str2 is not a rotation of each other"<<endl;
    }

    return 0;
}
