#include <iostream>
using namespace std;
//Tc = O(N) for traversing
//Sc = O(1) 
string solve(string strAns)
{
    for(int i=0;i<strAns.length();i++)
    {
        int ascii = (int) (strAns[i]); //Type-casting in int
        if(ascii == 90)
        {
            strAns[i] = char (65);
        }
        else if(ascii == 122)
        {
            strAns[i] = char (97);
        }
        else if((ascii >= 65 && ascii < 90) || (ascii >= 97 && ascii < 122) )
        {
            strAns[i] = char (ascii + 1);
        }
    }
    return strAns;
}

int main()
{
    string str = "abcdxyz";
    cout<<"The string become : "<<solve(str);
    return 0;
}
