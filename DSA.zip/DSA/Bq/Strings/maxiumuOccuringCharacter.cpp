//Maximum occuring character in string 
#include <iostream>
using namespace std;
//Tc = O(N)
//Sc = O(1)
char maxOccurringChar(string str)
{
    char ch;
    int maxichar = 0;
    //Purpose of taking the 256 is it will print the 
    //character in ascending order
    int count[256] = {0};
    int n = str.length();
    
    for(int i=0;i<n;i++)
    {
        count[str[i]]++;
        if(count[str[i]] > maxichar)
        {
            maxichar = count[str[i]];
            ch = str[i];
        }
    }
    return ch;
}

int main()
{
    string str = "takeuforward";
    cout << "Maximum occurring character is " << maxOccurringChar(str) << endl;
    return 0;
}
