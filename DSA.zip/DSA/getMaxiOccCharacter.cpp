#include <iostream>
using namespace std;

char getMaxiOccCharaater(string s)
{
    int arr[26] = {0};
    int n = s.length();
    int count = 0;
    for(int i=0;i<n;i++)
    {
        count = s[i] - 'a';
        arr[count]++;
    }
    
    int maxi = -1,ans = 0;
    for(int i=0;i<26;i++)
    {
        if(maxi < arr[i])
        {
            maxi = arr[i];
            ans = i;
        }
    }
    
    char result = 'a' + ans;
    return result;
}

int main()
{
    string str;
    cin>>str;
    cout<<getMaxiOccCharaater(str);

    return 0;
}
