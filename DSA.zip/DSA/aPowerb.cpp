#include <iostream>
#include <vector>
#include <math.h>
using namespace std;

int main()
{
    /*//brute force
    int a,b;
    cin>>a>>b;
    int ans = 1;
    //mutliply a for b times
    for(int i=0;i<b;i++)
    {
        ans = ans * a;
    }
    cout<<ans;*/
    int x,n;
    cin>>x>>n;
    int res = 1;
    while(n>0)
    {
        //odd
        if(n&1)
        {
            res = res * x;
        }
        x = x*x;
        n = n >> 1; //n = n/2;
    }
    cout<<res;
    return 0;
}
