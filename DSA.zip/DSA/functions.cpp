#include <iostream>

using namespace std;

/*void printEven(int n)
{
    for(int i=2;i<=n;i=i+2)
    {
        cout<<i<<" ";
    }
}*/

/*void printSquare(int n)
{
    for(int i=1;i<=n;i++)
    {
        cout<<i*i<<" , ";
    }
}*/


/*int printFact(int n)
{
    int ans = 1;
    for(int i=n;i>=i;i--)
    {
        ans = ans * i;
    }
    return ans;
}*/

/*void printName(int n)
{
    for(int i=1;i<=n;i++)
    {
        cout<<"Pankaj"<<endl;
    }
}*/


//declaration to function is always upper when they call

/*void printArrayElement(int arr[],int size) //make sure array k sath always size liya karo (good pratice)
{
     for (int i = 0; i <5; i++)
    {
      cout << arr[i] << " ";
    }
      cout << endl;
}*/




int main ()
{
  //int n = 21;
  //printEven(n);
  //int n = 25;
  //printSquare(n);
  //int n = 5;
  //int fact = printFact(5);
  //cout<<fact<<endl;
  //int n=10;
  //printName(10);
  //int arr[5] = { 1, 2, 3, 4, 5 };
  //garbage value or 0 (compiler dependent) but always coms 0
  //int size = sizeof(arr)/sizeof(int); //not always execute
  //cout<<size<<endl;
    //printArrayElement(arr,5);

  //cout << "Base Address of arr is : " << arr << endl;
  
  return 0;
}
