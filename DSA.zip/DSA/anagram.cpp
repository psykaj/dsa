//1 approch = sort and check
#include <iostream>
#include <string.h>
#include <algorithm>
using namespace std;
bool checkAnagram(string a,string b)
{ 
    int n1 = a.length();
    int n2 = b.length();
    
    if(n1 != n2)
    {
        return false;
    }
    
    sort(a.begin(),a.end());
    sort(b.begin(),b.end());
    
    for(int i=0;i<n1;i++)
    {
        if(a[i] != b[i])
        {
            return false;
        }
    }
    return true;
}

int main()
{ 
    string a = "babbar";
    string b = "rbbbaa";
    cout<<"Answer is : ";
    if(checkAnagram(a,b))
    {
        cout<<"Valid anagram";
    }
    else
    {
        cout<<"Not a Valid anagram";
    }
    return 0;
}

//valid for small cases only
//optimal approch
#include <iostream>
#include <string.h>
using namespace std;

bool checkAnagram(string a,string b)
{
    int freq[26] = {0}; //every alphabet is 0;
    for(int i=0;i<a.length();i++)
    {
        char ch = a[i];
        int index = ch - 'a';
        freq[index]++;
        
    }
    
    for(int i=0;i<b.length();i++)
    {
        char ch = b[i];
        int index = ch - 'a';
        freq[index]--;
        
    }
    
    bool flag = true;
    
    for(int i=0;i<26;i++)
    {
        if(freq[i] != 0)
        {
            return false;
        }
    }
    return true;
}


int main()
{
    /*string str;
    //getline(cin,str);
    cin>>str; //after every word there may (space/tab/newline) is called delimiter 
    //so after word it terminates.so these issues resolve with getline(cin,variable_name);
    cout<<"string is : "<<str<<endl;*/
    string a = "babbar";
    string b = "rbbbaa";
    cout<<"answer is : ";
    if(checkAnagram(a,b))
    {
        cout<<"Valid anagram";
    }
    else
    {
        cout<<"Not a Valid anagram";
    }
    return 0;
}



//using map
#include <iostream>
#include <string.h>
#include <map>
#include <algorithm>
using namespace std;
bool checkAnagram(string a,string b)
{
    map<char,int> m;
    for(int i=0;i<a.length();i++)
    {
        char ch = a[i];
        m[ch]++;
        
    }
    
    for(int i=0;i<a.length();i++)
    {
        char ch = b[i];
        m[ch]--;
        
    }
    
    for(auto i : m)
    {
        if(i.second != 0)
        {
            return false;
        }
    }
    return true;
}


int main()
{
    string a = "babbar";
    string b = "rbbnaa";
    if(checkAnagram(a,b))
    {
        cout<<"Valid anagram";
    }
    else
    {
        cout<<"Not a Valid anagram";
    }
    return 0;
}


//minimum flips of binary in string (h.w)
#include <iostream>
#include <string.h>
#include <algorithm>
using namespace std;

char flips(char expected)
{
    if(expected == '0')
    {
        return '1';
    }
    else
    {
        return '0';
    }
}

int miniFlips(string str, char expected)
{
    int countFlips = 0;
    for(int i=0;i<str.length();i++)
    {
        if(str[i] != expected)
        {
            countFlips++;
        }
        expected = flips(expected);
    }
    return countFlips;
}

int main()
{
    string str = "0010";
    int ans0 = miniFlips(str,'0');
    cout<<"Minimum flips when starts with 0 : "<<ans0<<endl;
    int ans1 = miniFlips(str,'1');
    cout<<"Minimum flips when starts with 1 : "<<ans1<<endl;
    int ans = min(ans0,ans1);
    cout<<"The minimum answer from 0 and 1 is : "<<ans<<endl;
    return 0;
}


