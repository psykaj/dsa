//Duplicate element in an array (brute-force)
//it will only work for duplicate 
#include <iostream>
using namespace std;

void printDuplicate(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(arr[i] == arr[j])
            {
                cout<<arr[i]<<" ";
            }
        }
    }
}


int main()
{
    int n;
    cout<<"Input size : ";
    cin>>n;
    int arr[n];
    cout<<"Input an array Element : ";
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"The Duplicate Element in an array is : ";
    printDuplicate(arr,n);
    return 0;
}



//find duplicate in an array of n+1 integers (optimise)
/*#include <iostream>
using namespace std;
void findDuplicate(int arr[],int n)
{
    //count the frequency
    for(int i=0;i<n;i++)
    {
        //jo bhi number milega arr[i] mai uske index per jaakar hum
        //vo array ka (element + n) kar denge  
        arr[arr[i]%n] = arr[arr[i]%n] + n;
//i.e =   arr[1%7] = 1 phir aaray k index number 1 mai jaakar check (arr[1] mai kya hai)
// phir arr[1] = 2 then arr[1] = 2 + 7 = 9
//similarly sab array ka aisa hi karo
    }
    cout<<"Repeating element in an array : ";
    //then again traverse that updated array 
    for(int i=0;i<n;i++) 
    {
        //if updated array has arr[i] element/n > 1 then print that index
        if(arr[i]/n > 1)
        {
            cout<<i<<" ";
        }
    }
}

int main()
{
    int arr[] = {1, 2, 3, 6, 3, 6, 1};
    int n = sizeof(arr) / sizeof(arr[0]);
    findDuplicate(arr,n);
    return 0;
}*/


















