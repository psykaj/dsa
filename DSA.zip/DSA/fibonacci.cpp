#include <iostream>
using namespace std;

void printFib(int n)
{
    int a = -1; //new approch in taking -1 and 1
    int b = 1;
    //cout<<a<<" "<<b<<" ";
    for(int i=1;i<=n;i++)
    {
        int c = a+ b;
        cout<<c<<" ";
        a=b;
        b=c;
    }
}

int main()
{
    int n;
    cin>>n;
    printFib(n);
    return 0;
}
