#include<bits/stdc++.h>
using namespace std;
/*int printFirstNonRepeating(int arr[],int n)
{
    unordered_map<int,int> m;
    //store count 
    for(int i=0;i<n;i++)
    {
        //int currEle = arr[i];
        m[arr[i]]++;
    }
    
    //traverse array and find ans
    for(int i=0;i<n;i++)
    {
        //int currEle = arr[i];
        if(m[arr[i]] == 1)
        {
            return arr[i];
        }
    }
    return -1;
}

int main()
{
    int arr[] = {9 ,4 ,9 ,6 ,7 ,4};
    int n = sizeof(arr) / sizeof(arr[0]);
    cout<<printFirstNonRepeating(arr, n);
    return 0;
}*/

//print first repeating element
/*int printFirstNonRepeating(int arr[],int n)
{
    unordered_map<int,int> m;
    //store count 
    for(int i=0;i<n;i++)
    {
        //int currEle = arr[i];
        m[arr[i]]++;
    }
    
    //traverse array and find ans
    for(int i=0;i<n;i++)
    {
        //int currEle = arr[i];
        if(m[arr[i]] > 1)
        {
            return arr[i];
        }
    }
    return -1;
}

int main()
{
    int arr[] = {10,5,3,4,3,5,6};
    int n = sizeof(arr) / sizeof(arr[0]);
    cout<<printFirstNonRepeating(arr, n);
    return 0;
}*/