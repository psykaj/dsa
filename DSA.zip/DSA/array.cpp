#include <iostream>
using namespace std;
//linear search
/*bool search(int arr[],int size,int target)
{
    for(int i=0;i<size;i++)
    {
        if(arr[i] == target)
        {
            cout<<i<<" "<<arr[i]<<endl;
            return true;
        }
    }
      return false;
}

int main ()
{
    int arr[100];
    int n;
    cout<<"Enter the size of arr : "<<endl;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];   
    }
    cout<<"Print the element of array : "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";   
    }
    cout<<endl;
    if(search(arr,5,7))
    {
        cout<<"milla"<<endl;
    }
    else
    {
        cout<<"Nhi milla"<<endl;
    }
  return 0;
}

//find mini and maxi numbers in an array
#include <iostream>
#include <climits>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    
    int mini = INT_MAX;
    int maxi = INT_MIN;
    for(int i=0;i<n;i++)
    {
        if(mini > arr[i])
        {
            mini = arr[i];
        }
        else if(maxi < arr[i])
        {
            maxi = arr[i];
        }
    }
    cout<<"Th minimum number in an array is : "<<mini<<endl;
    cout<<"Th maximum number in an array is : "<<maxi<<endl;
    return 0;
}


#include <iostream>
using namespace std;
void sort012(int arr[],int size)
{
    int high = size-1;
    int low = 0;
    int mid = 0;
    //ducth national flag algorithm
    while(mid<=high)
    {
        switch(arr[mid])
        {
            case 0:
                swap(arr[low++],arr[mid++]);
                break;
                
            case 1:
                mid++;
                break;
                
            case 2:
                swap(arr[mid],arr[high--]);
                break;
        }
    }
}

//print an array
void print(int arr[],int size)
{
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int n;
    cin>>n;
    int arr[n];
    int size = sizeof(arr)/sizeof(arr[0]);
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    sort012(arr,size);
    print(arr,size);
    return 0;
}

//move all negative numbers one side
#include <iostream>
using namespace std;

void moveNegativeNumbers(int arr[],int size)
{
    int j=0;
    for(int i=0;i<size;i++)
    {
        if(arr[i]<0)
        {
            if(i != j)
            {
                swap(arr[i],arr[j]);
                j++;
            }
        }
    }
    
}

void print(int arr[],int size)
{
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int n;
    cin>>n;
    int arr[n];
    int size = sizeof(arr)/sizeof(arr[0]);
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    moveNegativeNumbers(arr,size);
    sort(arr,arr+size);
    print(arr,size);
    return 0;
}*/




