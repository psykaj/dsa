#include <iostream>
#include <algorithm>
using namespace std;
//Tc = O(nlogn)
//Sc = O(1)
/*int findDiff(int arr[],int n)
{
    int maxCount = 0,minCount = 0,count = 0;
    sort(arr,arr+n);
    for(int i=0;i<n;i++)
    {
        if(arr[i] == arr[i+1])
        {
            count++;
            cout<<arr[i]<<"->"<<"Count : "<<count<<endl;
            continue;
        }
        else
        {
            maxCount = max(maxCount,count);
            cout<<"Max Count : "<<maxCount<<endl;
            minCount = min(minCount,count);
            cout<<"Min Count : "<<minCount<<endl;
            count = 0;
        }
    }
    
    int ans = maxCount - minCount;
    
    return ans;
}

int main()
{
    int arr[] = { 7, 8, 4, 5, 4, 1, 1, 7, 7, 2, 5 };
    int n = sizeof(arr) / sizeof(arr[0]);
    cout<<findDiff(arr, n);
    cout<<"The Distance between highest and lowest is : "<<endl;
    return 0;
}*/

//2 Approch
#include <bits/stdc++.h>
using namespace std;
//Tc = O(n)
//Sc = O(1)
int findDiff(int arr[],int n)
{
    map<int,int> m;
    for(int i=0;i<n;i++)
    {
        m[arr[i]]++;
    }
    
    int maxCount = 0;
    int minCount = n;
    for(auto i:m)
    {
        maxCount = max(maxCount,i.second);
        minCount = min(minCount,i.second);
    }
    
    int ans = maxCount - minCount;
    
    return ans;
}

int main()
{
    int arr[] = { 7, 8, 4, 5, 4, 1, 1, 7, 7, 2, 5 };
    int n = sizeof(arr) / sizeof(arr[0]);
    cout<<"The difference between highest and lowest is : "<<findDiff(arr, n)<<"\n";
    return 0;
}

