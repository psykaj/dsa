#include <iostream>
using namespace std;
//row sum
void rowSum(int arr[4][2] , int row, int col)
{
    int sum = 0;
    for(int i=0;i<row;i++)
    {
        int sum = 0;
        for(int j=0;j<col;j++)
        {
            sum = sum + arr[i][j];
        }
        cout<<sum<<" ";
    }
}
//col sum
void colSum(int arr[4][2] , int row, int col)
{
    int sum = 0;
    for(int i=0;i<col;i++)
    {
        int sum = 0;
        for(int j=0;j<row;j++)
        {
            sum = sum + arr[j][i];
        }
        cout<<sum<<" ";
    }
}

int main()
{
    int arr[4][2] = {{1,2},{2,3},{3,4},{4,5}};
    //cout<<search(arr,5,3,3);
    cout<<"Rows sum : ";
    rowSum(arr,4,2);
    cout<<endl;
    cout<<"Columns sum : ";
    colSum(arr,4,2);
    return 0;
}

//transpose
#include <iostream>
using namespace std;
void
findTranspose (int arr[][3], int n)
{
  for (int i = 0; i < n; i++)
    {
      for (int j = 0; j < i; j++)
    {
      swap (arr[i][j], arr[j][i]);
    }
    }
}

int
main ()
{
  int arr[][3] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
  int n = sizeof (arr) / sizeof (arr[0]);
  cout<<"Before swap : "<<endl;
  for (int i = 0; i < n; i++)
    {
      for (int j = 0; j < n; j++)
    {
      cout << arr[i][j] << " ";
    }
      cout << endl;
    }

  findTranspose (arr, n);
  
  cout<<"After swap : "<<endl;
  for (int i = 0; i < n; i++)
    {
      for (int j = 0; j < n; j++)
    {
      cout << arr[i][j] << " ";
    }
      cout << endl;
    }
  return 0;
}



//binary search (search element)
#include <iostream>
using namespace std;

bool search(int arr[][3],int n,int m,int row,int target)
{
    int s = 0;
    int e = n-1;
    int mid = s + (e-s)/2;
    while(s<=e)
    {
        if(arr[row][mid] == target)
        {
            cout<<row<<" "<<mid<<endl;
            return true;
        }
        
        if(arr[row][mid] < target)
        {
            s = mid + 1;
        }
        else
        {
            e =  mid - 1;
        }
        
        mid = s + (e-s)/2;
    }
    return false;
}

bool binarySearch (arr[][3], int n, int m, int target)
{
  int s = 0;
  int e = n - 1;
  int mid = s + (e - s) / 2;
  while (s <= e)
    {
      //check starting element of row
      if (arr[mid][0] == target)
    {
        cout<<mid <<" "<<0<<endl;
      return true;
    }

      //check ending element of row
      if (arr[mid][m - 1] == target)
    {
        cout<<mid <<" "<<m-1<<endl;
      return true;
    }

      if (target > arr[mid][0] && target < arr[mid][m - 1])
    {
      int ans = search (arr, n, m, mid, target);
      return ans;
    }

      //check upper part
      if (target < arr[mid][0])
    {
      e = mid - 1;
    }

      if (target > arr[mid][m - 1])
    {
      s = mid + 1;
    }
    
    mid = s + (e-s)/2;

    }
}

int
main ()
{
  int arr[3][3] = { 1, 4, 9, 14, 20, 21, 30, 34, 43 };
  int n = 3;
  int m = 3;
  int target = 34;
  binarySearch (arr, 3, 3, 34);
  return 0;
}

