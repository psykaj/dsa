#include <iostream>
using namespace std;
int solve(int coins[],int size,int amount,int currentCoin)
{
    if(amount == 0)
    {
        return 1;
    }
    
    if(amount<0)
    {
        return 0;
    }
    
    //use every coins
    int ways = 0;
    for(int i=currentCoin;i<size;i++)
    {
        ways += solve(coins,size,amount-coins[i],i);
    }
    return ways;
}

int main()
{
    int coins[] = {1,2};
    int size = sizeof(coins)/sizeof(coins[0]);
    int amount = 4;
    
    int ans = solve(coins,size,amount,0);
    cout<<ans<<endl;

    return 0;
}

//optimal game strategy
#include <iostream>
using namespace std;

int optimalStrategy(int arr[],int i,int j)
{
    if(i > j)
    {
        return 0;
    }
    
    int choice1 = arr[i] + min(optimalStrategy(arr,i+1,j),optimalStrategy(arr,i+1,j-1));
    int choice2 = arr[i] + min(optimalStrategy(arr,i+1,j-1),optimalStrategy(arr,i,j-2));
    
    int ans = max(choice1,choice2);
    
    return ans;
}

int main()
{
    
    int arr[] = {20,30,2,2,2,10};
    int i=0;
    int j=5;
    cout<<"ans is : "<<optimalStrategy(arr,i,j)<<endl;
    
    return 0;
}
