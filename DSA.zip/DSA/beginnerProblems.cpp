//Median of an array
/*#include <iostream>
#include <algorithm>
using namespace std;
void median(int arr[],int n)
{
    //sort the array 
    sort(arr,arr+n);
    //check even or odd 
    if(n%2 == 0)
    {
        int index1 = (n/2)-1;
        int index2 = n/2;
        cout<<(double)(arr[index1]+arr[index2])/2;
    }
    else
    {
        cout<<arr[(n/2)];
    }
}

int main()
{
    int arr[] = {1,2,4,5,6,7,8};
    int n = sizeof(arr)/sizeof(arr[0]);
    cout<<"The median of an array is : ";
    median(arr,n);
    return 0;
}*/

//Remove Duplicate in an array
/*#include <iostream>
#include <algorithm>
using namespace std;
int removeDuplicate(int arr[],int n)
{
    int i=0; 
    for(int j=1;j<n;j++)
    {
        if(arr[i] != arr[j])
        {
            i++;
            arr[i] = arr[j];//copy arr[j] element to arr[i] & increment
        }
    }
    return i+1;
}
int main()
{
    int arr[] = {1,1,2,2,2,3,3};
    int n = sizeof(arr)/sizeof(arr[0]);
    int k = removeDuplicate(arr,n);
    for(int i=0;i<k;i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}
//Method 2
#include <iostream>
#include <set>
using namespace std;
int removeDuplicate(int arr[],int n)
{
    set<int> s;
    for(int i=0;i<n;i++)
    {
        s.insert(arr[i]);
    }
    
    int setKaSize = s.size();
    int j = 0;
    for(auto x:s) //put all the element of set in starting of an array
    { //because set always stores unique values
        arr[j] = x;
        j++;
    }
    return setKaSize;
}
int main()
{
    int arr[] = {1,1,2,2,2,3,3};
    int n = sizeof(arr)/sizeof(arr[0]);
    int k = removeDuplicate(arr,n);
    for(int i=0;i<k;i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}*/


