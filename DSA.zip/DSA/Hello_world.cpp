#include <iostream>
using namespace std;
int main()
{	
	/*int a =5;
	cout<<"The value of a is : "<<a<<endl;

	bool b = 1;
	cout<<"value of b is : "<<b<<endl;
	cout<<"The size of b is : "<<sizeof(b)<<endl;

	float f = 1.23;
	cout<<"The value of f is :" <<f<<endl;

	cout<<"The size of f is : "<<sizeof(f)<<endl;

	char ch = 'p';
	cout<<"the value of ch is : "<<ch<<endl;
	cout<<"The size of ch is : "<<sizeof(ch)<<endl;

	float val1 = 5.0;
    int val2 = 3;
    int ans = val1/val2;
    cout<<"ans is "<<ans <<endl;
    cout<<"ans is "<<(5.0/3)<<endl;
    char character = 'a';
    int num = (int)character; ///TypeCatsing
    cout<<"The value of num is : "<<num<<endl;

    int num;
    cin>>num;
    if(num>0)
    {
    	cout<<"Number is positive";
    }
    else
    {
    	cout<<"Number is negative";
    }


	float a,b;
	cin>>a>>b;
	char op;
	cin>>op;
	switch(op)
	{
		case '+': cout<<a+b<<endl;
					break;

		case '-': cout<<a-b<<endl;
					break;

		case '*': cout<<a*b<<endl;
					break;

		case '/': cout<<a/b<<endl;
					break;

		default: cout<<"No operation";



	}

	int num = 5;
	int sum=0;
	while(num!=0)
	{
		
		sum = sum + num;
		num--;
	}

	cout<<sum<<endl;

	int n=10;
	for(int i=1;i<=n;i++)
	{
		cout<<2*i<<endl;
		break;
	}

	int n=5;
	cout<<n++<<endl;
	cout<<n<<endl;
	cout<<++n<<endl;

	int n=10;
	for(int i=1;i<=n;i++) //variable scoping
	{
		
		cout<<i<<endl;
		if(i%2 == 0)
		{
			continue;
		}
	}

	int n=10;
	for(;;)
	{
		if(n>0)
		{
			cout<<"pankaj"<<endl;
		}
		else
		{
			break;
		}	
		n--;
	}
	cout<<"khatam hua na bhai"<<endl;

	if(true)
	{
		int n=5;
		cout<<n<<endl;
		if(true)//local variable scope reference
		{
		int n=6;
		cout<<n<<endl;
		}
		cout<<n<<endl;
	}*/
	



	return 0;
}