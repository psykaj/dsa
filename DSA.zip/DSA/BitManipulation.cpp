/*#include <iostream>
using namespace std;

int main()
{
    //cout<<"Hello World";
    int n;
    cin>>n;
    int i=1;
    while(i<=n)
    {
        if(i&1 == 1) //ager apne ko janna ho ki last bit number mai konsa hai 
        //tho hamesha [& 1] kardo (acha aur fast hota hai). v.imp
        {
            cout<<i<<" is an odd number"<<endl;
        }
        else
        {
            cout<<i<<" is an even number"<<endl;
        }
        i++;
    }

    
    return 0;
}*/

//Check weather number is even or Odd
//brute force (method-1)
//Tc = O(1);
//Sc = O(1);
/*#include <iostream>
using namespace std;
bool solve(int n)
{
    if((n & 1) == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    int n;
    cin>>n;
    
    bool k = solve(n);
    
    if(k)
    {
        cout<<n<<" is Even Number"<<endl;
    }
    else
    {
        cout<<n<<" is Odd Number"<<endl;
    }
    
    return 0;
}*/

//Optimal Approch (Method-2)
//Check weather number is even or Odd
//Tc = O(1)
//Sc = O(1)
/*void check(int n)
{
    //bit is always fatest way 
    if(n>>31 == 0) //(0-31) is 4 bytes = 32 bit
    {
        cout<<"Positive Number"<<endl;
    }
    else
    {
        cout<<"Negative Number"<<endl;
    }
}

int main()
{
    int n;
    cin>>n;
    check(n);
    return 0;
}*/

//Sum of N natural Number
#include <iostream>
using namespace std;
//Brute force 
//Tc = O(N); one for loop
//Sc = O(1);
/*int add(int n)
{
    int sum = 0;
    for(int i=0;i<=n;i++)
    {
        sum += i;
    }
    return sum;
}

int main()
{
    int n;
    cin>>n;
    cout<<add(n)<<endl;
    return 0;
}*/

//Optimal Approch
//Tc = O(1);
//Sc = O(1);
/*int main()
{
    int n;
    cin>>n;
    int sum = n*(n+1)/2;
    cout<<sum<<endl;
    return 0;
}*/



