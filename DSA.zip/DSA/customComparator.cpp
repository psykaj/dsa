#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void printVector(vector<vector<int>> v,int n)
{
    for(int i=0;i<n;i++)
    {
        vector<int>&temp = v[i];
        int a = temp[0];
        int b = temp[1];
        cout<<a<<" "<<b<<endl;
    }
}

bool myCompfor1stIndex(vector<int>&a , vector<int>&b) 
{
    // 0 based indexing sorting 
    // return a[0] < b[0];
    
    // Incresing Order 1 based indexing
    return a[1] < b[1];
    
    // Descresing Order 1 based indexing
    // return a[1] > b[1];
}

int main()
{
    vector<vector<int>> v;
    
    int n;
    cout<<"Enter Size of n : ";
    cin>>n;
    
    for(int i=0;i<n;i++)
    {
        int a,b;
        cout<<"Enter a abd b : "<<endl;
        cin>>a>>b;
        vector<int> temp;
        temp.push_back(a);
        temp.push_back(b);
        v.push_back(temp);
    }
    cout<<endl;
    cout<<"Here is the output : "<<endl;
    printVector(v,n);
    
    // sort vector by index 0
    // sort(v.begin(),v.end());
    // cout<<"sort vector by index 0 : "<<endl;
    // printVector(v,n);
    
    // sort index by index 1 => by using custom comparator
    sort(v.begin(),v.end(), myCompfor1stIndex);
    cout<<"sort vector by index 0 : "<<endl;
    printVector(v,n);
    
    

    return 0;
}
